
/**********************************************************

history：
build time: 2017-11-22
author     : lirui

Copyright (c)   

************************************************************/


#include "netsocket.h"
#include "netmanager.h"
#include "gmthread.h"
#include "gmlog.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include <sys/epoll.h>
#include <pthread.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/un.h>

#include <stdlib.h>


int      iExit_netmanager = 0 ;
#define IRIS_SERVICE_SOCKET_NAME "iris_service_socket"

struct pair
{
   int mode ;
   int used  ;
   int sockets[2] ;
} ;

struct pair  hptable[64] ;

int  net_connect_recv(int socketid)
{
         char data[4] ;
         int num , i  ,  size  ,  len ;

         if ((netsck_canrsize(socketid , &size) < 0) || (size <= 0))
         {
                 
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can read data size from client[%d : %d] wrongly!" , socketid , size) ;
              }
              return  -1;
         }
         
        if (netsck_recv(socketid , data , sizeof(data)) != sizeof(data))
         {
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can read data size from client[%d] wrongly!" , socketid) ;
              }
              return  -1;
         }
         
         int type = 0;
         get_int(data , &type , 1) ;
         
         
         if (hptable[type].mode == 0)
         {
         	if (socketpair(AF_UNIX, SOCK_SEQPACKET, 0, hptable[type].sockets)) {
			        
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The service cannot creat socket pair!") ;
			        return -2;
		        }

	        int bufferSize = 32 * 1024;
	        setsockopt(hptable[type].sockets[0], SOL_SOCKET, SO_SNDBUF, &bufferSize,
			           sizeof(bufferSize));
	        setsockopt(hptable[type].sockets[0], SOL_SOCKET, SO_RCVBUF, &bufferSize,
			           sizeof(bufferSize));
	        setsockopt(hptable[type].sockets[1], SOL_SOCKET, SO_SNDBUF, &bufferSize,
			           sizeof(bufferSize));
	        setsockopt(hptable[type].sockets[1], SOL_SOCKET, SO_RCVBUF, &bufferSize,
			           sizeof(bufferSize));
			hptable[type].mode = 1;
			
			printf("socket pair %d %d \n" , hptable[type].sockets[0] , hptable[type].sockets[1]) ;
         }
         
         if (hptable[type].used == 1)
         {
            hptable[type].used = 0 ;	
            hptable[type].mode = 0;
            send_fd(socketid , hptable[type].sockets[1]) ;
            printf("from %d   send [1]%d \n" , socketid , hptable[type].sockets[1]) ;
            close(hptable[type].sockets[1]) ;
            return 0 ;
         }
         
         if (hptable[type].used == 0)
         {
           send_fd(socketid , hptable[type].sockets[0]) ;
           hptable[type].used = 1 ;
           printf("from %d   send[0] %d \n" , socketid , hptable[type].sockets[0]) ;
           close(hptable[type].sockets[0]) ;
         }
        
        return 0 ;
}

int    netservice_init(const char *address)
{
        
        int server_sockfd, client_sockfd;
        int server_len, client_len;
        struct sockaddr_un server_address; /*声明一个UNIX域套接字结构*/
        struct sockaddr_un client_address;
        unlink (address); /*删除原有server_socket对象*/

        /*创建 socket, 通信协议为AF_UNIX, SCK_STREAM 数据方式*/
        server_sockfd = socket (AF_LOCAL, SOCK_STREAM | SOCK_CLOEXEC, 0);
        if (server_sockfd < 0 )
        {
           write_log(ENC_LOGLEVEL_FATAL , 128 , "the program will exit! for it can not build the server, return code[%x]!" , server_sockfd) ;
           return -1 ;
        }
        
        memset(hptable , 0 , sizeof (hptable)) ;
        /*配置服务器信息(通信协议)*/
        server_address.sun_family = AF_LOCAL;

        /*配置服务器信息(socket 对象)*/
        server_address.sun_path[0] = '\0';
        strcpy (&server_address.sun_path[1], address);

        /*配置服务器信息(服务器地址长度)*/
        server_len = offsetof(struct sockaddr_un, sun_path) + 1 +
                                                            strlen(address);
        int code = socket_noblock(server_sockfd , 1) ;
        
        if (code < 0)
        {
            write_log(ENC_LOGLEVEL_FATAL , 128 , " socket_noblock the program will exit! for it can not build the server, return code[%x]!" , code) ;
            socket_close(server_sockfd) ;
            server_sockfd = -1 ;
            return code ;
        }
              
        /*绑定 socket 对象*/
        code = bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
        
        if (code < 0)
        {
            write_log(ENC_LOGLEVEL_FATAL , 128 , " bind the program will exit! for it can not build the server, return code[%x]!" , code) ;
            socket_close(server_sockfd) ;
            server_sockfd = -1 ;
            return code ;
        }
        
        /*监听网络,队列数为5*/
        listen (server_sockfd ,  5);

        printf ("Server[%d] is waiting for client connect...\n" , server_sockfd);

        client_len = sizeof (client_address);

        struct epoll_event  listen_event ;

        int epoll_listen = epoll_create(10) ;
        listen_event.data.fd = server_sockfd ;
        listen_event.events = EPOLLIN | EPOLLET ;

        epoll_ctl(epoll_listen , EPOLL_CTL_ADD , server_sockfd ,  &listen_event) ;

        struct epoll_event   events[64] ;
        int num , i  ,  j , sckid , size = sizeof(struct sockaddr_in)   ;

        write_log(ENC_LOGLEVEL_INFO , 128 , "The listen start!") ;
        while(1)
        {
               if (IsExit() == 1)
                   break ;
               num = epoll_wait(epoll_listen , events , 64 ,  5000) ;
               if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
               {
                      write_log(ENC_LOGLEVEL_DEBUG , 128 , "The server listen epoll_wait return code[%d]!" , num) ;
               }

               if (num <= 0)
               {
                   continue ;
               }

               for (i = 0 ; i < num ; ++i)
               {
                   if (events[i].data.fd == server_sockfd)
                   {
                       sckid = accept(server_sockfd ,  (struct  sockaddr*)&client_address , (socklen_t *)&client_len) ;
                       if (sckid == -1)
                       {
                            if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                                   write_log(ENC_LOGLEVEL_ERROR , 128 , "The server accept client connets wrongly!") ;
                            continue ;
                       }

                       write_log(ENC_LOGLEVEL_INFO , 128 , "The service accept client[%d]!" , sckid) ;
                       
                       struct epoll_event  c_event ;
                       c_event.data.fd = sckid ;
                       c_event.events =  EPOLLIN | EPOLLET ;
                       epoll_ctl(epoll_listen , EPOLL_CTL_ADD , sckid , &c_event) ;
                       continue ;
                   }
                   
                   if (net_connect_recv(events[i].data.fd ) >= 0)
                      continue ;
                  epoll_ctl(epoll_listen ,  EPOLL_CTL_DEL , events[i].data.fd  , NULL) ;
                  close(events[i].data.fd ) ;                      

                  write_log(ENC_LOGLEVEL_INFO , 128 , "The service del client[%d]!" , events[i].data.fd) ;            
               }
        }

        epoll_ctl(epoll_listen , EPOLL_CTL_DEL , server_sockfd , NULL) ;
        close(epoll_listen) ;
        close(server_sockfd) ;
        write_log(ENC_LOGLEVEL_WARN , 128 , "The listem thread exits!") ;
        ++iExit_netmanager ;
       
      return 0 ;
}

void  netservice_stop()
{
      int i ;
       while(iExit_netmanager < 1)
           usleep(500000) ;
}
