#pragma once

//#include "IrisUtilsCommon.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
//IrisUtils_NAMESPACE {
    int send_fd(int fd, int fd_to_send);
    int recv_fd(int fd);
//};
