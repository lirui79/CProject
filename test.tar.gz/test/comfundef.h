/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   

************************************************************/



#ifndef  COM_FUN_DEFINED_H
#define COM_FUN_DEFINED_H 1



int    IsExit() ; // 1 - true  0 - false

void   SetExit(int nExit) ;

int    put_char(unsigned char *data  , char value) ;
int    put_uchar(unsigned char *data  , unsigned char value) ;

int    put_short(unsigned char *data  , short value, int big) ;
int    put_ushort(unsigned char *data  , unsigned short value, int big) ;

int    put_int(unsigned char *data  , int value , int big) ;
int    put_uint(unsigned char *data  , unsigned int value, int big) ;

int    put_long(unsigned char *data  , long value, int big) ;
int    put_ulong(unsigned char *data  , unsigned long value, int big) ;

int    put_longlong(unsigned char *data  , long long value, int big) ;
int    put_ulonglong(unsigned char *data  , unsigned long long value, int big) ;

int    put_data(unsigned char *data , const  char *value ,  int sz) ;

int    get_char(const unsigned  char *data  , char *value) ;
int    get_uchar(const unsigned  char *data  , unsigned char  *value) ;

int    get_short(const unsigned  char *data  , short  *value, int big) ;
int    get_ushort(const unsigned  char *data  , unsigned short  *value, int big) ;

int    get_int(const unsigned  char *data  , int  *value , int big) ;
int    get_uint(const unsigned  char *data  , unsigned int  *value, int big) ;

int    get_long(const unsigned  char *data  , long  *value, int big) ;
int    get_ulong(const unsigned  char *data  , unsigned long  *value, int big) ;

int    get_longlong(const unsigned  char *data  , long long  *value, int big) ;
int    get_ulonglong(const unsigned  char *data  , unsigned long long  *value, int big) ;

int    get_data(const unsigned  char *data , unsigned  char *value ,  int sz) ;

int    get_string(const unsigned  char *data , int sz ,  char *sztemp , int mlen) ;

#endif //COM_FUN_DEFINED_H
