
/**********************************************************

history：
build time: 2017-11-22
author     : lirui

Copyright (c)   

************************************************************/


#include "netsocket.h"
#include "netmanager.h"
#include "gmthread.h"
#include "gmlog.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include <sys/epoll.h>
#include <pthread.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>


typedef   struct netsck_ctx
{
    char       address[ENC_MAX_ADDRESS] ;
    unsigned char       *data ;//[ENC_MAX_LEN]
    int          rsz ;
    int          rmlen ;
    int          socketid ;
    int          used ;
}netsck_ctx;

struct netsck_ctx       netsck_ctxs[ENC_MAX_CON] ;
struct   m_cond_t      netsck_mcondt ;
struct netsck_ctx*     netsck_tasks[ENC_MAX_CON] ;

struct netmanager_ctx
{
     int  epoll_listen ;
     int  epoll_recv ;
     int  sckid_recv ;
} ;

int      iExit_netmanager = 0 ;

void *netlisten(void *args)
{
        struct netmanager_ctx *netm_ctx = (struct netmanager_ctx *)args ;
        struct epoll_event   events[ENC_MAX_LISTEN] ;
        int num , i  ,  j , sckid , size = sizeof(struct sockaddr_in)  ,  add ;
        struct  sockaddr_in clientAddr ;
        struct epoll_event  c_event ;
       write_log(ENC_LOGLEVEL_INFO , 128 , "The listem thread start!") ;
        while(1)
        {
               if (IsExit()  == 1)
                   break ;
               num = epoll_wait(netm_ctx->epoll_listen , events , ENC_MAX_LISTEN ,  ENC_MAX_TIMEOUT) ;
               if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
               {
                      write_log(ENC_LOGLEVEL_DEBUG , 128 , "The server listen epoll_wait return code[%d]!" , num) ;
               }

               if (num <= 0)
               {
                   continue ;
               }

               for (i = 0 ; i < num ; ++i)
               {
                   if (events[i].data.fd != netm_ctx->sckid_recv)
                        continue ;

                   sckid = accept(netm_ctx->sckid_recv ,  (struct  sockaddr*)&clientAddr , &size) ;
                   if (sckid == -1)
                   {
                        if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                        {
                                write_log(ENC_LOGLEVEL_ERROR , 128 , "The server accept client connets wrongly!") ;
                        }
                       continue ;
                   }

                   write_log(ENC_LOGLEVEL_INFO , 128 , "The server accept client[%s:%d]!" , inet_ntoa(clientAddr.sin_addr) , sckid) ;

                   add = 0 ;
                   for (j = 0 ; j < ENC_MAX_CON ; ++j)
                   {
                         if (netsck_ctxs[j].used == 1)
                             continue ;
                         netsck_ctxs[j].used = 1 ;
                         netsck_ctxs[j].socketid = sckid ;
                         netsck_ctxs[j].rsz  = 0 ;
                         strncpy(netsck_ctxs[j].address , inet_ntoa(clientAddr.sin_addr) , ENC_MAX_ADDRESS) ;
                         c_event.data.ptr = (void*) &netsck_ctxs[j] ;
                         c_event.events =  EPOLLIN | EPOLLET ;
                         epoll_ctl(netm_ctx->epoll_recv , EPOLL_CTL_ADD , sckid , &c_event) ;
                         add = 1 ;
                         break ;
                   }

                   if (add == 1)
                        continue ;
                   if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                   {
                            write_log(ENC_LOGLEVEL_ERROR , 128 , "The server accept client[%s:%d] , but not space!" , inet_ntoa(clientAddr.sin_addr) , sckid) ;
                   }
                   close(sckid) ;
               }
        }

        epoll_ctl(netm_ctx->epoll_listen , EPOLL_CTL_DEL , netm_ctx->sckid_recv , NULL) ;
        close(netm_ctx->sckid_recv) ;
        close(netm_ctx->epoll_listen) ;
        write_log(ENC_LOGLEVEL_WARN , 128 , "The listem thread exits!") ;
        ++iExit_netmanager ;
        return NULL ;
}

int  net_connect_recv(struct netsck_ctx *netsck_c_ctx)
{
         char  *szTemp ;
         int num , i  ,  size  ,  len ;

         if ((netsck_canrsize(netsck_c_ctx->socketid , &size) < 0) || (size <= 0))
         {
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can read data size from client[%s:%d] wrongly!" , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
              }
              return  -1;
         }

        if ((netsck_c_ctx->rsz + size) > netsck_c_ctx->rmlen)
        {
           if (netsck_c_ctx->rsz < 5)
           {
                len = (5 - netsck_c_ctx->rsz)  ;
                if( len != netsck_recv(netsck_c_ctx->socketid ,  netsck_c_ctx->data + netsck_c_ctx->rsz  , len))
                {
                      if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                      {
                            write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can receive data size[%d] from client[%s:%d] wrongly!" , size , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
                      }
                      return  -2 ;
                }
                netsck_c_ctx->rsz  += len ;
                size -= len ;
           }
           get_int(netsck_c_ctx->data + 1 ,  &len , 1) ;
           len += 5 ;
           if (len > netsck_c_ctx->rmlen)
           {
                szTemp = malloc(len) ;
                memcpy(szTemp , netsck_c_ctx->data , netsck_c_ctx->rsz) ;
                free(netsck_c_ctx->data) ;
                netsck_c_ctx->data = szTemp ;
                netsck_c_ctx->rmlen = len ;
           }
        }

        if (size != netsck_recv(netsck_c_ctx->socketid , netsck_c_ctx->data + netsck_c_ctx->rsz , size))
        {
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can receive data size[%d] from client[%s:%d] wrongly!" , size , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
              }
              return  -3 ;
        }

        netsck_c_ctx->rsz += size ;
        if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
        {
              len = 3 * netsck_c_ctx->rsz + 1 ;
              szTemp = malloc(len) ;
              get_string(netsck_c_ctx->data , netsck_c_ctx->rsz , szTemp , len) ;
              write_log(ENC_LOGLEVEL_DEBUG ,  len + 256 , "The server can receive data[%d][%d:%s] from client[%s:%d] successfully!" , size , netsck_c_ctx->rsz , szTemp , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
              free(szTemp) ;
        }

        if (netsck_c_ctx->rsz < 5)
            return  0;

        get_int(netsck_c_ctx->data + 1 ,  &len , 1) ;

        if ((len + 5) >  netsck_c_ctx->rsz )
            return  0;

        pthread_mutex_lock(&(netsck_mcondt.mutex));
        for (i = 0 ; i < ENC_MAX_CON ; ++i)
        {
             if (netsck_tasks[i] != NULL)
                  continue ;
            netsck_tasks[i] =  netsck_c_ctx ;
            break ;
        }
        pthread_mutex_unlock(&(netsck_mcondt.mutex));
        thread_signal(&netsck_mcondt);
        return 1 ;
}

void *netrecieve(void *args)
{
       struct netmanager_ctx *netm_ctx = (struct netmanager_ctx *)args ;
       struct epoll_event   events[ENC_MAX_EVENTS] ;
       int num , i ;
       struct netsck_ctx  *netsck_c_ctx ;
       write_log(ENC_LOGLEVEL_INFO , 128 , "The receive thread start!") ;
       while(1)
        {
               if (IsExit()  == 1)
                   break ;

               num = epoll_wait(netm_ctx->epoll_recv , events , ENC_MAX_EVENTS ,  ENC_MAX_TIMEOUT) ;
               if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
               {
                      write_log(ENC_LOGLEVEL_DEBUG , 128 , "The server receive epoll_wait return code[%d]!" , num) ;
               }

               if (num <= 0)
               {
                   continue ;
               }

               for (i = 0 ; i < num ; ++i)
               {
                      netsck_c_ctx =(struct netsck_ctx *) events[i].data.ptr ;
                      if (net_connect_recv(netsck_c_ctx) >= 0)
                          continue ;
                      epoll_ctl(netm_ctx->epoll_recv ,  EPOLL_CTL_DEL , netsck_c_ctx->socketid , NULL) ;
                      close(netsck_c_ctx->socketid) ;
                      netsck_c_ctx->used = 0 ;
               }
        }

        close(netm_ctx->epoll_recv) ;
        write_log(ENC_LOGLEVEL_WARN , 128 , "The receive thread exits!") ;
        ++iExit_netmanager ;
        return NULL ;
}


void *nettaskrun(void *args)
{
       struct netmanager_ctx *netm_ctx = (struct netmanager_ctx *)args ;
       struct netsck_ctx  *netsck_c_ctx ;
       int  j , sz  , len , msz = ENC_MAX_LEN ,  code ;
       unsigned char *data ;
       char *szTemp , *sztmp ;
       write_log(ENC_LOGLEVEL_INFO , 128 , "The execute task thread start!") ;
       data = malloc(msz) ;

       while(1)
        {
                if (IsExit()  == 1)
                   break ;
                netsck_c_ctx = NULL ;
                pthread_mutex_lock(&(netsck_mcondt.mutex));
                for (j = 0 ; j < ENC_MAX_CON ; ++j)
                {
                     if (netsck_tasks[j] == NULL)
                          continue ;
                    netsck_c_ctx =  netsck_tasks[j] ;
                    netsck_tasks[j] =  NULL ;
                    break ;
                }
                pthread_mutex_unlock(&(netsck_mcondt.mutex));
                if (netsck_c_ctx == NULL)
                {
                     thread_wait(&netsck_mcondt , ENC_MAX_TIMEOUT);
                    continue ;
                }

               code =  gm_encrypt_fun(netsck_c_ctx->data ,  netsck_c_ctx->rsz , &data , &sz , &msz) ;

               if (code != SDR_OK)
                {
                      len = 3 * netsck_c_ctx->rsz  + 4 ;
                      szTemp = malloc(len) ;
                      len = get_string(netsck_c_ctx->data  , netsck_c_ctx->rsz  , szTemp , len) ;
                      sztmp = malloc(3 * sz  + 4) ;
                      len += get_string(data  , sz  , sztmp , 3 * sz  + 4) ;

                      write_log(ENC_LOGLEVEL_ERROR , 256 + len , "The server calculates the data  got from client[%s:%d] , and  which are from [%d:%s] changed to [%d:%s] , code[%x]!" , netsck_c_ctx->address , netsck_c_ctx->socketid , netsck_c_ctx->rsz , szTemp , sz , sztmp , code) ;
                      free(sztmp) ;
                      free(szTemp) ;
               }
               else
               {
                    if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
                    {
                          len = 3 * netsck_c_ctx->rsz  + 4 ;
                          szTemp = malloc(len) ;
                          len = get_string(netsck_c_ctx->data  , netsck_c_ctx->rsz  , szTemp , len) ;
                          sztmp = malloc(3 * sz  + 4) ;
                          len += get_string(data  , sz  , sztmp , 3 * sz  + 4) ;

                          write_log(ENC_LOGLEVEL_DEBUG , 256 + len , "The server calculates the data  got from client[%s:%d] , and  which are from [%d:%s] changed to [%d:%s] , code[%x]!" , netsck_c_ctx->address , netsck_c_ctx->socketid , netsck_c_ctx->rsz , szTemp , sz , sztmp , code) ;
                          free(sztmp) ;
                          free(szTemp) ;
                   }
               }

                netsck_c_ctx->rsz = 0 ;

                if (netsck_send(netsck_c_ctx->socketid , data , sz) != sz)
                {
                          if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                          {
                              len = 3 * sz + 4 ;
                              szTemp = malloc(len) ;
                              get_string(data , sz , szTemp , len) ;
                              write_log(ENC_LOGLEVEL_ERROR , 256 + len , "The server sent data[%s] to client[%s:%d] wrongly!" , szTemp , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
                              free(szTemp) ;
                          }
                          epoll_ctl(netm_ctx->epoll_recv ,  EPOLL_CTL_DEL , netsck_c_ctx->socketid , NULL) ;
                          close(netsck_c_ctx->socketid) ;
                          netsck_c_ctx->used = 0 ;
                          continue ;
                }

               if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
               {
                  len = 3 * sz + 4 ;
                  szTemp = malloc(len) ;
                  get_string(data , sz , szTemp , len) ;
                  write_log(ENC_LOGLEVEL_DEBUG , 256 + len , "The server sent data[%s] to client[%s:%d] successfully!" , szTemp , netsck_c_ctx->address , netsck_c_ctx->socketid) ;
                  free(szTemp) ;
              }
        }

        free(data) ;
        write_log(ENC_LOGLEVEL_WARN , 128 , "The execute task thread exits!") ;
        ++iExit_netmanager ;
        return NULL ;
}


int    netmanager_init(const char *address , unsigned short  port)
{
        struct epoll_event  listen_event ;
        static  struct netmanager_ctx netm_ctx ;
        int i ;
        netm_ctx.sckid_recv = netsck_bind(address ,  port ,  AF_INET , SOCK_STREAM , 0 , 1)  ;
        if (netm_ctx.sckid_recv < 0)
        {
           write_log(ENC_LOGLEVEL_FATAL , 128 , "the program will exit! for it can not build the server, return code[%x]!" , netm_ctx.sckid_recv) ;
           return -1 ;
        }
       thread_mcond_t_init(&netsck_mcondt) ;
       for (i = 0 ; i < ENC_MAX_CON ; ++i)
       {
             netsck_ctxs[i].used = 0 ;
             netsck_ctxs[i].data = malloc(ENC_MAX_LEN) ;
             netsck_ctxs[i].rmlen = ENC_MAX_LEN ;
             netsck_tasks[i] = NULL ;
        }

        listen(netm_ctx.sckid_recv , 5) ;

        netm_ctx.epoll_listen = epoll_create(10) ;
        listen_event.data.fd = netm_ctx.sckid_recv ;
        listen_event.events = EPOLLIN | EPOLLET ;

        epoll_ctl(netm_ctx.epoll_listen , EPOLL_CTL_ADD , netm_ctx.sckid_recv ,  &listen_event) ;

        netm_ctx.epoll_recv = epoll_create(50000) ;

        thread_run(netlisten , &netm_ctx) ;
        thread_run(netrecieve , &netm_ctx) ;
        thread_run(nettaskrun , &netm_ctx) ;
        return 0 ;
}

void  netmanager_stop()
{
      int i ;
       while(iExit_netmanager < 3)
           usleep(500000) ;

       for (i = 0 ; i < ENC_MAX_CON ; ++i)
       {
             if (netsck_ctxs[i].data != NULL)
                 free(netsck_ctxs[i].data) ;
             netsck_ctxs[i].data = NULL ;
             netsck_ctxs[i].rmlen = 0 ;
             if (netsck_ctxs[i].used == 0)
                 continue ;
             close(netsck_ctxs[i].socketid) ;
             netsck_ctxs[i].used = 0 ;
        }
      thread_mcond_t_destroy(&netsck_mcondt) ;
}
