
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   

************************************************************/



#ifndef  GM_THREAD_H
#define GM_THREAD_H 1


#include <pthread.h>




void   thread_run( void* (*th_fn)(void *args) , void *args) ;

typedef struct   m_cond_t
{
    pthread_mutex_t    mutex ;
    pthread_cond_t      cond_t ;
    int                         signal ;
} m_cond_t ;

int      thread_mcond_t_init( struct  m_cond_t * mcond_t) ;

void    thread_mcond_t_destroy( struct  m_cond_t * mcond_t) ;

int      thread_wait(struct  m_cond_t * mcond_t , unsigned  int ts) ;

void   thread_signal(struct  m_cond_t * mcond_t) ;


#endif // GM_THREAD_H


