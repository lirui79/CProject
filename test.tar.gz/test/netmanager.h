
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/



#ifndef  NTE_MANAGER_H
#define NTE_MANAGER_H 1
  

int    netmanager_init(const char *address , unsigned short  port) ;

void  netmanager_stop() ;

#endif // NTE_MANAGER_H

