
#include "comfundef.h"
#include "gmthread.h"
#include "gmlog.h"
#include "netserver.h"
#include <stdio.h>
#include <signal.h>



struct   m_cond_t   g_m_cond_t ;

void signal_handler(int sig)
{
	SetExit(1) ;	//
	write_log(ENC_LOGLEVEL_WARN , 128 , "press <Ctrl-C> the program will end!") ;
}

void set_signal(int sig)
{
	struct sigaction sa;
	sa.sa_handler = SIG_IGN;//
	sa.sa_flags = 0;//	sigemptyset(&sa.sa_mask);
	sigaction(sig , &sa, 0) ;
}

void Sleep(unsigned int ts)
{
      thread_wait(&g_m_cond_t , ts);
}


int main (int argc, char *argv[])
{
    struct sigaction sa;    /* Establish the signal handler. */
    logserver_init(ENC_LOGLEVEL_DEBUG) ;//ENC_LOGLEVEL_WARN
    thread_mcond_t_init(&g_m_cond_t) ;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = ( void (*)(int) )signal_handler ;
    sigaction(SIGINT , &sa, NULL);
    
    char *args[] = {"/tmp/testservice.socket" , argv[1]} ;
    
    netserver_init(args) ;

    while(1)
    {
        if (IsExit()  == 1)
            break ;

	     printf("net server main thread running!\n") ;
        //Sleep(5000) ;
        char c = {0};
        char szTemp[128] = {0} ;
        printf("please input:") ;
        scanf("%s" , szTemp) ;
        
        int code = net_send(szTemp , strlen(szTemp)) ;
       //int code = net_send(argv[2] , strlen(argv[2])) ;
        printf("send data: %d \n" , code) ;
        
        //Sleep(5000) ;
    }

    write_log(ENC_LOGLEVEL_INFO , 128 , "the program will be exit!") ;
    netserver_stop() ;
    stop_log()  ;
    Sleep(500) ;
    thread_mcond_t_destroy(&g_m_cond_t) ;

    return 0 ;
}
