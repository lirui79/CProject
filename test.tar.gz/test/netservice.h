
/**********************************************************

history：
build time: 2017-11-10
author     : lirui

Copyright (c)   

************************************************************/



#ifndef  NTE_SERVICE_H
#define NTE_SERVICE_H 1
  

int    netservice_init(const char *address) ;

void   netservice_stop() ;

#endif // NTE_SERVICE_H

