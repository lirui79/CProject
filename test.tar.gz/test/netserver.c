
/**********************************************************

history：
build time: 2017-11-22
author     : lirui

Copyright (c)   

************************************************************/


#include "netsocket.h"
#include "gmthread.h"
#include "gmlog.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include <sys/epoll.h>
#include <pthread.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/un.h>

#include <stdlib.h>


int      iExit_netmanager = 0 ;
int      gsokcetid = -1 ;
int  net_connect_recv(int socketid)
{
         char data[4096] ;
         int  size  ,  len ;

         if ((netsck_canrsize(socketid , &size) < 0) || (size <= 0))
         {                        
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can read data size from client[%d %d] wrongly!" , socketid , size) ;
              }
              return  -1;
         }
         
        if (netsck_recv(socketid , data , size) != size)
         {
              if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
              {
                    write_log(ENC_LOGLEVEL_ERROR , 128 , "The server can read data size from client[%d] wrongly!" , socketid) ;
              }
              return  -1;
         }
         
         char *szTemp ;
        szTemp = malloc(3 * size  + 4) ;
        len = get_string(data  , size  , szTemp , 3 * size  + 4) ;

        write_log(ENC_LOGLEVEL_DEBUG , 256 + len , "The server calculates the data  got from client[%d] , and  which are [%d:%s] !" , socketid , size , szTemp) ;
        free(szTemp) ;
         
         return 0 ;
}

int    netserver_thread(const char *szaddress , int ntype)
{ 
        struct sockaddr_un address;

        int sockfd;
        int len;
         /*创建socket,AF_LOCAL通信协议,SOCK_STREAM数据方式*/
        if ((sockfd = socket(AF_LOCAL, SOCK_STREAM | SOCK_CLOEXEC, 0)) == -1) {
            write_log(ENC_LOGLEVEL_FATAL , 128 , "socket not create");
            return -1 ;
        }

        int code = socket_noblock(sockfd , 1) ;
        
        if (code < 0)
        {
            write_log(ENC_LOGLEVEL_FATAL , 128 , " socket_noblock the program will exit! for it can not build the server, return code[%x]!" , code) ;
            socket_close(sockfd) ;
            sockfd = -1 ;
            return code ;
        }
        
        address.sun_family = AF_LOCAL;
        address.sun_path[0] = '\0';
        strcpy (&address.sun_path[1], szaddress);
        len = offsetof(struct sockaddr_un, sun_path) + 1 +
              strlen(szaddress);

        /*向服务器发送连接请求*/
        code = connect (sockfd, (struct sockaddr *)&address, len);
        if (code < 0) {
            write_log(ENC_LOGLEVEL_FATAL , 128 , "ensure the server is up\n");
            return -2 ;
        }
        
        printf ("Server[%d] is waiting for client data...\n", sockfd);

        struct epoll_event  listen_event ;

        int epoll_listen = epoll_create(10) ;
        listen_event.data.fd = sockfd ;
        listen_event.events = EPOLLIN | EPOLLET ;

        epoll_ctl(epoll_listen , EPOLL_CTL_ADD , sockfd ,  &listen_event) ;
        
        code = netsck_select(sockfd , 1000 , 1) ;
        
        if (code == 0)
        {
           unsigned char data[4] ;
           put_int(data , ntype , 1) ;
           code = netsck_send(sockfd , data , sizeof(data)) ;
           write_log(ENC_LOGLEVEL_DEBUG , 128 , "can send[%s:%d] type to service %d\n" , szaddress , sockfd , code);   
        } else {
            write_log(ENC_LOGLEVEL_FATAL , 128 , "can not send type to service\n");   
            epoll_ctl(epoll_listen ,  EPOLL_CTL_DEL , sockfd  , NULL) ;     
            socket_close(sockfd) ;
            sockfd = -1 ;
            close(epoll_listen) ;
            return -3 ;
        }

        struct epoll_event   events[64] ;
        int num , i  ,  j , sckid , size = sizeof(struct sockaddr_in)   ;
        struct epoll_event  c_event ;
        write_log(ENC_LOGLEVEL_INFO , 128 , "The listen start!") ;
        int nDel = 0 ;
        while(1)
        {
               if (IsExit() == 1)
                   break ;
               num = epoll_wait(epoll_listen , events , 64 ,  5000) ;
               if (get_loglevel() <= ENC_LOGLEVEL_DEBUG)
               {
                      write_log(ENC_LOGLEVEL_DEBUG , 128 , "The server listen epoll_wait return code[%d]!" , num) ;
               }

               if (num <= 0)
               {
                   continue ;
               }

               for (i = 0 ; i < num ; ++i)
               {
                   if (nDel == 0 && events[i].data.fd == sockfd)
                   {
                       sckid = recv_fd(sockfd);
                       if (sckid == -1)
                       {
                            if (get_loglevel() <= ENC_LOGLEVEL_ERROR)
                                   write_log(ENC_LOGLEVEL_ERROR , 128 , "The server accept client connets wrongly!") ;
                            continue ;
                       }

                       write_log(ENC_LOGLEVEL_INFO , 128 , "The server get socket [%d]!" , sckid) ;
                       int code = socket_noblock(sckid , 1) ;
                       
                       c_event.data.fd = sckid ;
                       c_event.events =  EPOLLIN | EPOLLET ;
                       epoll_ctl(epoll_listen , EPOLL_CTL_ADD , sckid , &c_event) ;
                       gsokcetid = sckid ;
                       epoll_ctl(epoll_listen ,  EPOLL_CTL_DEL , sockfd  , NULL) ;
                       write_log(ENC_LOGLEVEL_INFO , 128 , "The server del socket [%d]!" , sockfd) ;
                       close(sockfd) ;  
                       nDel = 1 ;
                      continue ;
                   }
                   
                   if (net_connect_recv(events[i].data.fd ) >= 0)
                      continue ;
                  epoll_ctl(epoll_listen ,  EPOLL_CTL_DEL , events[i].data.fd  , NULL) ;
                  close(events[i].data.fd ) ;                   
               }
        }

        if (nDel == 0)
        {
            epoll_ctl(epoll_listen , EPOLL_CTL_DEL , sockfd , NULL) ;
            close(sockfd) ;
        } else {
            epoll_ctl(epoll_listen , EPOLL_CTL_DEL , gsokcetid , NULL) ;
            close(gsokcetid) ; 
        }
          
        close(epoll_listen) ;
        write_log(ENC_LOGLEVEL_WARN , 128 , "The listem thread exits!") ;
        ++iExit_netmanager ;
       
      return 0 ;
}

void *netserver_run(void *args)
{
    char **argv = (char **)args;
    netserver_thread(argv[0] , atoi(argv[1])) ;
}


int    netserver_init(char *args[]){ 
      thread_run(netserver_run , &args[0]) ; 
 }

void  netserver_stop()
{
      int i ;
       while(iExit_netmanager < 1)
           usleep(500000) ;
}


int    net_send(const char *data , int size)
{   
printf("data :%d \n" , size) ;
     unsigned char vdata[1024] ;
     int len = 0 ;
     size = put_data(vdata , data , size) ;
     
           char *szTemp ;
        szTemp = malloc(3 * size  + 4) ;
        len = get_string(vdata  , size  , szTemp , 3 * size  + 4) ;

        write_log(ENC_LOGLEVEL_DEBUG , 256 + len , "The server calculates the data  send from client[%d] , and  which are [%d:%s] !" , gsokcetid , size , szTemp) ;
        free(szTemp) ;   
     
     int  code = netsck_select(gsokcetid , 1000 , 1) ;
     if (code != 0)
     {
         printf("can not send data \n" , code) ;
         return -1 ;
     }

     code = netsck_send(gsokcetid , data , size) ;
     printf("netsck_send %d\n" , code) ;
     return code ;
}
