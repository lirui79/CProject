
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)  

************************************************************/



#ifndef  GM_LOG_H
#define GM_LOG_H 1

#define        ENC_LOGLEVEL_DEBUG             0
#define        ENC_LOGLEVEL_INFO              1
#define        ENC_LOGLEVEL_WARN              2
#define        ENC_LOGLEVEL_ERROR             3
#define        ENC_LOGLEVEL_FATAL             4

int      logserver_init(int iloglevel) ;

void   set_loglevel(int iloglevel) ;

int      get_loglevel() ;

int      write_log(int  iloglevel , int ilogsize , const char *format , ...)  ;

void   stop_log() ;




#endif // GM_LOG_H



