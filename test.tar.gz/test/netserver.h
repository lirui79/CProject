
/**********************************************************

history：
build time: 2017-11-10
author     : lirui

Copyright (c)   

************************************************************/



#ifndef  NTE_SERVER_H
#define  NTE_SERVER_H 1
  

int    netserver_init(char *args[]) ;

void   netserver_stop() ;

int    net_send(const char *data , int size) ;

#endif // NTE_SERVICE_H

