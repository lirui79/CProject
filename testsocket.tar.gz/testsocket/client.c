#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <fcntl.h>

#include "SocketFd.h" 
#include "netsocket.h"

#define UNIXSTR_PATH "foo.socket"
#define OPEN_FILE  "test"

#define SOCK_STREAM_TEST

struct msg_data {
      
   union {
   
   char data[128] ;
   
   struct {   
	   int type ;
	   int size ;
	   
        char msg[32] ;
        int  len ;
        int   hdafa ;
        
        long  lflag ;
        
        double  pos ;
        
        float   dir ;
   
      } ;
   
   } ;
   
} ;








int main(int argc, char *argv[])
{
	int clifd;
	struct sockaddr_un servaddr;  //IPC
	int ret;
	struct msghdr msg;
	struct iovec iov[1];
	char buf[100];
	union {  //保证cmsghdr和msg_control对齐
		struct cmsghdr cm;
		char control[CMSG_SPACE(sizeof(int))];
	} control_un;
	struct cmsghdr *pcmsg;
	int fd;

#ifdef  SOCK_STREAM_TEST
	clifd  = socket(AF_UNIX, SOCK_STREAM, 0) ;
#else
	clifd  = socket(AF_UNIX, SOCK_SEQPACKET, 0) ;
#endif

	if   ( clifd  <  0 ) {
		printf ( "socket failed.\n" ) ;
		return  - 1 ;
	}

	fd  =  open(OPEN_FILE ,O_CREAT | O_RDWR, 0777);
	if( fd  <  0 ) {
		printf("open test failed.\n");
		return -1;
	}

	bzero (&servaddr, sizeof(servaddr));
	servaddr.sun_family = AF_UNIX;
	strcpy ( servaddr.sun_path, UNIXSTR_PATH);

	ret = connect(clifd, (struct sockaddr*)&servaddr, sizeof(servaddr));
	if(ret < 0) {
		printf ( "connect failed.\n" ) ;
		return 0;
	}
    int id = 0 ;
    while(1)
    {  
    struct msg_data  msg1 ;
    msg1.size = 56 ;
#ifdef  SOCK_STREAM_TEST    
    int code = recv_msg(clifd , msg1.data , &msg1.size) ;   
#else
    int code = netsck_recv(clifd , msg1.data , msg1.size) ;   
#endif
  

        if (code > 0)  
        {
           printf("client recv: %d %d  %d %s %d  %d %d %d \n" , id++ , msg1.type , msg1.size , msg1.msg , msg1.len , msg1.hdafa , msg1.lflag , code) ;
        }   
        
     char  szrbuf[64] = {0} ;

    int len = 13 ;
#ifdef  SOCK_STREAM_TEST    
         code = recv_msg(clifd , szrbuf , &len) ; 
#else
         code = netsck_recv(clifd , szrbuf , len) ; 
#endif

     if (code > 0)  
           printf("client recv:%d  %s  %d \n" , id++ , szrbuf , code ) ;
    //char szbuf[32] = "hello world!" ;
    
    
    //printf("server recv: %s  %d \n" , szrbuf , len ) ;
 
   // code = send_msg(clifd , szbuf , strlen(szbuf) + 1) ;   
    

    }   



	return 0 ;
}
