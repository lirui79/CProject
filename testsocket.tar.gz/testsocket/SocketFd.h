#pragma once

//#include "IrisUtilsCommon.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
//IrisUtils_NAMESPACE {

    int send_fd(int fd, int send_fd) ;
    int send_msg(int fd, const char *data , int size);
    int recv_msg(int fd , char *data , int *size);
    int recv_fd(const int sock_fd);
//};
