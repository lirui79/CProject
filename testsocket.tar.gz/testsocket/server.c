//server.c

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <fcntl.h>

#include "SocketFd.h" 
#include "netsocket.h"


#define UNIXSTR_PATH "foo.socket"

#define SOCK_STREAM_TEST

struct msg_data {

       
   union {
   
   char data[128] ;
   
   struct {   
	   int type ;
	   int size ;
	   
        char msg[32] ;
        int  len ;
        int   hdafa ;
        
        long  lflag ;
        
        double  pos ;
        
        float   dir ;
   
      } ;
   
   } ;
   
} ;




int main(int argc, char *argv[])
{
	int clifd, listenfd;
	struct sockaddr_un servaddr, cliaddr;
	int ret;
	socklen_t clilen;
	struct msghdr msg;
	struct iovec iov[1];
	char buf [100];
	char  *testmsg = "test msg.\n";


	int  recvfd;

#ifdef  SOCK_STREAM_TEST

	listenfd  =  socket ( AF_UNIX ,  SOCK_STREAM ,  0 ) ;
#else

	listenfd  =  socket ( AF_UNIX ,  SOCK_SEQPACKET ,  0 ) ;
	
#endif

	if(listenfd < 0) {
		printf ( "socket failed.\n" ) ;
		return  -1;
	}

	unlink(UNIXSTR_PATH) ;

	bzero (&servaddr, sizeof(servaddr));
	servaddr.sun_family = AF_UNIX;
	strcpy ( servaddr.sun_path ,  UNIXSTR_PATH ) ;

	ret  =  bind ( listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr));
	if(ret < 0) {
		printf ( "bind failed. errno = %d.\n" ,  errno ) ;
		close(listenfd);
		return  - 1 ;
	}

	listen(listenfd, 5);

	while(1) {
		clilen = sizeof( cliaddr );
		clifd = accept( listenfd, (struct sockaddr*)&cliaddr , &clilen);
		if ( clifd < 0 ) {
			printf ( "accept failed.\n" ) ;
			continue ;
		}
        int id = 0 ;
        while(1)
        {
        
        struct msg_data  msg1 ;
        msg1.type = id ;
        msg1.size = sizeof(int) * 2;
        
        msg1.len = sprintf(msg1.msg , "hello world!") ;
        msg1.size += sizeof(msg1.msg) + sizeof(msg1.len);
        msg1.hdafa = 10 ;
        msg1.size += sizeof(msg1.hdafa) ;
        msg1.lflag = 50 ;
        msg1.size += sizeof(msg1.lflag) ;
        
#ifdef  SOCK_STREAM_TEST                
        int code = send_msg(clifd , (char*)msg1.data , msg1.size) ;
#else
        int code = netsck_send(clifd , (char*)msg1.data , msg1.size) ;
#endif
        
        
        
        if (code >= 0)  
        {
           printf("server send: %d %d  %d %s %d  %d %d %d \n" , id++ , msg1.type , msg1.size , msg1.msg , msg1.len , msg1.hdafa , msg1.lflag , code) ;
        }
     
        char szbuf[32] = "how are you!" ;
        
        
#ifdef  SOCK_STREAM_TEST       
        code = send_msg(clifd , szbuf , strlen(szbuf) + 1) ;     
#else      
        code = netsck_send(clifd , szbuf , strlen(szbuf) + 1) ;     
#endif
             
            
         if (code >= 0)  
           printf("server send: %d %s  %d \n" , id++ , szbuf , code) ;
     
        
       // char  szrbuf[64]  ;
      //  int len = 64 ;
        
       // code = recv_msg(clifd , szrbuf , &len) ;
      //  printf("server recv: %s  %d \n" , szrbuf , code) ;
        }   
         

	}

	return 0 ;
}
