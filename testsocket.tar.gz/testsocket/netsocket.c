/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   

************************************************************/


#include "netsocket.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef  _WINDOWS
#include <time.h>
#include <winsock2.h>

#else
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#endif


int  socket_noblock(int sckid , int noblock)
{
#ifdef  _WINDOWS
	 u_long umode = 0 ;
	 if (noblock !=0)
		 umode = 1 ;
     return ioctlsocket(sckid , FIONBIO , &umode) ;
#else

	 return ioctl(sckid , FIONBIO , &noblock) ;
/*
     if (noblock > 1)
        return fcntl(sckid, F_SETFL, fcntl(sckid, F_GETFL) | O_NONBLOCK) ;
	 else
        return fcntl(sckid , F_SETFL, fcntl(sckid, F_GETFL) & ~O_NONBLOCK) ;//*/
#endif
}

void  socket_close(int sckid)
{
#ifdef  _WINDOWS
      closesocket(sckid) ;
#else
      close(sckid) ;
#endif
}


   /*
     * return code   >=0   socket id  < 0 error number
     * address  ip address   "192.168.6.20"
     * port        5000
     * domain   AF_INET  ipv4   AF_INET6  ipv6  AF_UNIX  unix   AF_ROUTE
     * type        SOCK_STREAM  SOCK_DGRAM  SOCK_RAW  SOCK_PACKET  SOCK_SEQPACKET
     * protocol  IPPROTO_TCP  IPPTOTO_UDP  IPPROTO_SCTP  IPPROTO_TIPC
     */
int   netsck_connect(const char *address ,  unsigned short port ,  int domain , int type , int protocol, int nonblock)
{
        int sckid = -1 ;
        int flags = 0 ;
        int code = 0 ;
       struct  sockaddr_in  servAddr ;
        sckid = socket(domain , type , protocol) ;
        if (sckid < 0)
            return -1 ;
		code = socket_noblock(sckid , nonblock);
        if (code  < 0)
        {
            socket_close(sckid) ;
            sckid = -1 ;
            return code ;
        }
        servAddr.sin_family = domain ;
        servAddr.sin_port  = htons(port) ;
        if (address == NULL)
        {
            servAddr.sin_addr.s_addr = htonl(INADDR_ANY) ;
        }
        else
        {
            servAddr.sin_addr.s_addr = inet_addr(address) ;
        }

        code = connect(sckid , (struct sockaddr*)&servAddr , sizeof(servAddr)) ;
        if (code < 0)
        {
            socket_close(sckid) ;
            sckid = -1 ;
            return code ;
        }

        return sckid ;
}

int   netsck_bind(const char *address , unsigned short port ,  int domain , int type , int protocol, int nonblock)
 {
        int sckid = -1 ;
        int flags = 0 ;
        int code = 0 ;
        int opt = 1 ;
        struct sockaddr_in  servAddr ;
        sckid = socket(domain , type , protocol) ;
        if (sckid < 0)
            return -1 ;
		code = socket_noblock(sckid , nonblock);
        if (code  < 0)
        {
            socket_close(sckid) ;
            sckid = -1 ;
            return code ;
        }

        code = setsockopt(sckid ,  SOL_SOCKET , SO_REUSEADDR ,(void*) &opt , sizeof(opt)) ;
        if (code < 0)
        {
            socket_close(sckid) ;
            sckid = -1 ;
            return code ;
        }

        servAddr.sin_family = domain ;
        servAddr.sin_port  = htons(port) ;
       if (address == NULL)
        {
            servAddr.sin_addr.s_addr = htonl(INADDR_ANY) ;
        }
        else
        {
            servAddr.sin_addr.s_addr = inet_addr(address) ;
        }

        code = bind(sckid , (struct sockaddr*)&servAddr , sizeof(servAddr)) ;

        if (code < 0)
        {
            socket_close(sckid) ;
            sckid = -1 ;
            return code ;
        }

        return sckid ;
 }

int   netsck_send(int socketid ,  const unsigned char *data , int size)
 {
        const unsigned char * ptr = data ;
        int len = size , sz ;
        if (socketid == -1)
            return -1 ;
        while(len > 0)
        {
            sz = send(socketid , ptr , len , MSG_NOSIGNAL) ;
			if (sz <= 0)
			{
#ifndef  _WINDOWS
                if (errno == EINTR)
                    sz = 0 ;
                else if (errno == EAGAIN)
                    sz = 0 ;
                else
#endif
				    return -2 ;
			}
            len -= sz ;
            ptr += sz ;
        }
       return (size - len) ;
 }


int   netsck_recv(int socketid ,  unsigned  char *data , int size)
{
    unsigned char *ptr = data ;
    int len = size  ,  sz;

    if (socketid == -1)
         return -1 ;

    while(len > 0)
    {
        sz = recv(socketid , ptr , len , MSG_NOSIGNAL) ;
        if (sz <= 0)
        {
#ifndef  _WINDOWS
            if (errno == EINTR)
                sz = 0 ;
            else if (errno == EAGAIN)
                sz = 0 ;
            else
#endif
                return -2 ;
        }
        len -= sz ;
        ptr += sz ;
    }
    return (size - len) ;
}

int   netsck_canrsize(int socketid ,   int *size)
 {
#ifdef  _WINDOWS
	 u_long usz = 0 ;
 	 int code = ioctlsocket(socketid , FIONREAD , &usz) ;
	 if (socketid == -1)
         return -1 ;
	 if(code != 0)
	 	return code ;
     *size = usz ;
#else
	 if (socketid == -1)
         return -1 ;
     if (ioctl(socketid , FIONREAD , size) != 0)
         return -2 ;
#endif
     return 0 ;
 }

int   netsck_select(int socketid , unsigned long ts , int type)
{
    fd_set fd;
	struct timeval tm;
	int code ;
	if (socketid == -1)
        return -1 ;
	tm.tv_sec = ts / 1000 ;
	tm.tv_usec = (ts % 1000) * 1000 ;
   	FD_ZERO(&fd);
	FD_SET(socketid , &fd);
	if (type != 0) //send
       code = select(socketid + 1 , NULL , &fd , NULL , &tm) ;
	else
       code = select(socketid + 1 , &fd , NULL , NULL , &tm) ;
    if (code > 0)
	    return 0 ;
	else if (code == 0)
        return -2 ;
	else
		return -3 ;
}
