#include "SocketFd.h"

#include <stdio.h>

#include <string.h>

#include <stdlib.h>



#include <unistd.h>

#include <sys/wait.h>

#include <sys/types.h>

#include <sys/stat.h>

#include <fcntl.h>

#include <errno.h>

//IrisUtils_NAMESPACE {
/*
static struct cmsghdr *cmptr = NULL;
static int CONTROLLEN = sizeof(struct cmsghdr) + sizeof(int);
static int MAXLINE = 100;

int send_fd(int fd, int fd_to_send) {
    struct iovec iov[1];
    struct msghdr msg;
    char buf[2];

    iov[0].iov_base = buf;
    iov[0].iov_len = 2;
    msg.msg_iov = iov;
    msg.msg_iovlen = 1;
    msg.msg_name = NULL;
    msg.msg_namelen = 0;

    if (fd_to_send <= 0) {
        return -1;
    }

    if (cmptr == NULL && (cmptr = (struct cmsghdr *) malloc(CONTROLLEN)) == NULL)
        return -1;
    cmptr->cmsg_level = SOL_SOCKET;
    cmptr->cmsg_type = SCM_RIGHTS;
    cmptr->cmsg_len = CONTROLLEN;
    msg.msg_control = cmptr;
    msg.msg_controllen = CONTROLLEN;
    *(int *) CMSG_DATA(cmptr) = fd_to_send;
    buf[1] = 0;
    buf[0] = 0;
    if (sendmsg(fd, &msg, 0) != 2)
        return -1;
    return 0;
}*/

int send_msg(int fd, const char *data , int size)
{
    int ret;
    struct msghdr msg;
    struct cmsghdr *p_cmsg;
    struct iovec vec;
    char cmsgbuf[CMSG_SPACE(sizeof(int))];
    int *p_fds;
    char sendchar = 0;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);
    p_cmsg = CMSG_FIRSTHDR(&msg);
    p_cmsg->cmsg_level = SOL_SOCKET;
    p_cmsg->cmsg_type = SCM_RIGHTS;
    p_cmsg->cmsg_len = CMSG_LEN(sizeof(int));
    p_fds = (int*)CMSG_DATA(p_cmsg);
    *p_fds = fd;


    msg.msg_name = NULL;
    msg.msg_namelen = 0;
    msg.msg_iov = &vec;
    msg.msg_iovlen = 1;
    msg.msg_flags = 0;

    vec.iov_base = data;
    vec.iov_len = size;
    ret = sendmsg(fd , &msg, 0);
    if (ret == -1)
    {
       printf("sendmsg error, errno is %d\n", errno);
       return -1 ;
    }
    return ret ;
}

int send_fd(int fd, int send_fd)
{
    int ret;
    struct msghdr msg;
    struct cmsghdr *p_cmsg;
    struct iovec vec;
    char cmsgbuf[CMSG_SPACE(sizeof(int))];
    int *p_fds;
    char sendchar = 0;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);
    p_cmsg = CMSG_FIRSTHDR(&msg);
    p_cmsg->cmsg_level = SOL_SOCKET;
    p_cmsg->cmsg_type = SCM_RIGHTS;
    p_cmsg->cmsg_len = CMSG_LEN(sizeof(int));
    p_fds = (int*)CMSG_DATA(p_cmsg);
    *p_fds = send_fd;


    msg.msg_name = NULL;
    msg.msg_namelen = 0;
    msg.msg_iov = &vec;
    msg.msg_iovlen = 1;
    msg.msg_flags = 0;

    vec.iov_base = &sendchar;
    vec.iov_len = sizeof(sendchar);
    ret = sendmsg(fd , &msg, 0);
    if (ret == -1)
    {
       printf("sendmsg error, errno is %d\n", errno);
       return -1 ;
    }
    return 0 ;
}


int recv_fd(const int sock_fd)
{
    int ret;
    struct msghdr msg;
    char recvchar;
    struct iovec vec;
    int recv_fd;
    char cmsgbuf[CMSG_SPACE(sizeof(int))];
    struct cmsghdr *p_cmsg;
    vec.iov_base = &recvchar;
    vec.iov_len = sizeof(recvchar);
    msg.msg_name = NULL;
    msg.msg_namelen = 0;
    msg.msg_iov = &vec;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);
    msg.msg_flags = 0;

    ret = recvmsg(sock_fd, &msg, 0);
    if (ret == -1)
    {
       printf("recvmsg error, errno is %d\n", errno);
       return -1 ;
    }


    p_cmsg = CMSG_FIRSTHDR(&msg);
    if (p_cmsg == NULL) 
    {
       printf("no passed fd\n");
       return -2 ;
    }
    
    recv_fd = *(int*)CMSG_DATA(p_cmsg);
    if (recv_fd == -1)
    {
       printf("no passed fd\n");
       return -3 ;
    }

    return recv_fd;
}


int recv_msg(int fd , char *data , int *size)
{
    int ret;
    struct msghdr msg;
    struct iovec vec;
    int recv_fd;
    char cmsgbuf[CMSG_SPACE(sizeof(int))];
    struct cmsghdr *p_cmsg;
    vec.iov_base = data;
    vec.iov_len = *size ;
    msg.msg_name = NULL;
    msg.msg_namelen = 0;
    msg.msg_iov = &vec;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);
    msg.msg_flags = 0;

    ret = recvmsg(fd , &msg, 0);
    if (ret == -1)
    {
       printf("recvmsg error, errno is %d\n", errno);
       return -1 ;
    }


    p_cmsg = CMSG_FIRSTHDR(&msg);
    if (p_cmsg == NULL) 
    {
       printf("no passed fd\n");
       return -2 ;
    }

    
    recv_fd = *(int*)CMSG_DATA(p_cmsg);
    if (recv_fd == -1)
    {
       printf("no passed fd\n");
       return -3 ;
    }
    close(recv_fd) ;
    *size = ret ;

    return ret ;
}


/*
int recv_fd(int fd, ssize_t (*userfunc)(int, const void *, size_t)) {
    int newfd, nr, status;
    char *ptr;
    char buf[MAXLINE];
    struct iovec iov[1];
    struct msghdr msg;

    status = -1;
    for (;;) {
        iov[0].iov_base = buf;
        iov[0].iov_len = sizeof(buf);
        msg.msg_iov = iov;
        msg.msg_iovlen = 1;
        msg.msg_name = NULL;
        msg.msg_namelen = 0;

        if (cmptr == NULL && (cmptr = (struct cmsghdr *) malloc(CONTROLLEN)) == NULL) {
            return -1;
        }

        msg.msg_control = cmptr;
        msg.msg_controllen = CONTROLLEN;
        if ((nr = recvmsg(fd, &msg, 0)) < 0) {
//          err_sys("recvmsg error");  
        } else if (nr == 0) {
//          err_ret("connection closed by server");  
            return -1;
        }

        for (ptr = buf; ptr < &buf[nr];) {
            if (*ptr++ == 0) {
                if (ptr != &buf[nr - 1]) {
//                  err_dump("message format error");  
                }
                status = *ptr & 0xFF;
                if (status == 0) {
                    if (msg.msg_controllen != CONTROLLEN) {
//                      err_dump("status = 0but no fd");  
                    }
                    newfd = *(int *) CMSG_DATA(cmptr);
                } else {
                    newfd = -status;
                }
                nr -= 2;
            }
        }

//      if (nr > 0 && (&userfunc)(STDERR_FILENO, buf, nr) != nr)  
//      {  
//          return -1;  
//      }  
        if (status >= 0)
            return newfd;
    }
}*/

//};
