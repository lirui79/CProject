/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/

#include "comfundef.h"
#include  <stdio.h>
#include  <string.h>

int   g_iExit = 0 ;

int    IsExit()
{
      return g_iExit ;
}


void   SetExit(int nExit)
{
      g_iExit = nExit ;
}

int    put_char(unsigned char *data  , char value)
{
     data[0] = (unsigned char)value ;
     return 1 ;
}

int    put_uchar(unsigned char *data  , unsigned char value)
{
     data[0] = value ;
     return 1 ;
}

int    put_short(unsigned char *data  , short value, int big)
{
     if (big != 0)
     {
           data[0] = (unsigned char) (value >> 8) ;
           data[1] =  (unsigned char)value ;
     }
     else
     {
           data[0] = (unsigned char) value ;
           data[1] = (unsigned char)(value >> 8) ;
     }
     return 2 ;
}

int    put_ushort(unsigned char *data  , unsigned short value, int big)
{
     if (big != 0)
     {
           data[0] = (unsigned char) (value >> 8) ;
           data[1] = (unsigned char)  value ;
     }
     else
     {
           data[0] = (unsigned char)  value ;
           data[1] = (unsigned char)  (value >> 8) ;
     }
     return 2 ;
}

int    put_int(unsigned char *data  , int value , int big)
{
     if (big != 0)
     {
           data[0] = (unsigned char)(value >> 24) ;
           data[1] = (unsigned char)(value >> 16) ;
           data[2] = (unsigned char)(value >> 8) ;
           data[3] = (unsigned char)value ;
     }
     else
     {
           data[0] = (unsigned char)value ;
           data[1] = (unsigned char)(value >> 8) ;
           data[2] = (unsigned char)(value >> 16) ;
           data[3] = (unsigned char)(value >> 24) ;
     }
     return 4 ;
}

int    put_uint(unsigned char *data  , unsigned int value, int big)
{
     if (big != 0)
     {
           data[0] = (unsigned char)(value >> 24) ;
           data[1] = (unsigned char)(value >> 16) ;
           data[2] = (unsigned char)(value >> 8) ;
           data[3] = (unsigned char)value ;
     }
     else
     {
           data[0] = (unsigned char)value ;
           data[1] = (unsigned char)(value >> 8) ;
           data[2] = (unsigned char)(value >> 16) ;
           data[3] = (unsigned char)(value >> 24) ;
     }
     return 4 ;
}

int    put_long(unsigned char *data  , long value, int big)
{
      if (sizeof(long) == 8)
          return put_longlong(data , (long long) value , big) ;
      else
          return  put_int(data , (int) value , big) ;
}


int    put_ulong(unsigned char *data  , unsigned long value, int big)
{
      if (sizeof(unsigned long) == 8)
           return put_ulonglong(data , (unsigned long long) value , big) ;
      else
           return put_uint(data , (unsigned int) value , big) ;
}

int    put_longlong(unsigned char *data  , long long value, int big)
{
     if (big != 0)
     {
           put_uint(data ,  (unsigned int)(value >> 32) ,  big) ;
           put_uint(data + 4 ,  (unsigned int)(value) ,  big) ;
     }
     else
     {
           put_uint(data ,  (unsigned int)(value) ,  big) ;
           put_uint(data + 4 ,  (unsigned int)(value >> 32) ,  big) ;
     }
     return 8 ;
}

int    put_ulonglong(unsigned char *data  , unsigned long long value, int big)
{
     if (big != 0)
     {
           put_uint(data ,  (unsigned int)(value >> 32) ,  big) ;
           put_uint(data + 4 ,  (unsigned int)(value) ,  big) ;
     }
     else
     {
           put_uint(data ,  (unsigned int)(value) ,  big) ;
           put_uint(data + 4 ,  (unsigned int)(value >> 32) ,  big) ;
     }
     return 8 ;
}

int    put_data(unsigned char *data , const  char *value ,  int sz)
{
     memcpy(data , value , sz) ;
     return sz ;
}

int    get_char(const unsigned  char *data  , char *value)
{
     *value = (char) data[0] ;
     return 1 ;
}

int    get_uchar(const unsigned  char *data  , unsigned char  *value)
{
     *value = data[0] ;
     return 1 ;
}

int    get_short(const unsigned  char *data  , short  *value, int big)
{
     if (big != 0)
     {
        *value = (short) (data[0] << 8) + (data[1]) ;
     }
     else
     {
        *value = (short) (data[1] << 8) + (data[0]) ;
     }
     return 2 ;
}

int    get_ushort(const unsigned  char *data  , unsigned short  *value, int big)
{
     if (big != 0)
     {
        *value =  ( unsigned short ) (data[0] << 8) + (data[1]) ;
     }
     else
     {
        *value =  ( unsigned short ) (data[1] << 8) + (data[0]) ;
     }
     return 2 ;
}

int    get_int(const unsigned  char *data  , int  *value , int big)
{
     if (big != 0)
     {
        *value =  (int) (data[0] << 24) + (data[1] << 16) +(data[2] << 8) + (data[3]) ;
     }
     else
     {
        *value =  (int) (data[3] << 24) + (data[2] << 16) +(data[1] << 8) + (data[0]) ;
     }
     return 4 ;
}

int    get_uint(const unsigned  char *data  , unsigned int  *value, int big)
{
     if (big != 0)
     {
        *value =  (unsigned int) (data[0] << 24) + (data[1] << 16) +(data[2] << 8) + (data[3]) ;
     }
     else
     {
        *value =  (unsigned int) (data[3] << 24) + (data[2] << 16) +(data[1] << 8) + (data[0]) ;
     }
     return 4 ;
}

int    get_long(const unsigned  char *data  , long  *value, int big)
{
     if (sizeof(long) == 8)
          return get_longlong(data , (long long*) value , big) ;
      else
          return  get_int(data , (int*) value , big) ;
}

int    get_ulong(const unsigned  char *data  , unsigned long  *value, int big)
{
     if (sizeof(unsigned long) == 8)
          return get_ulonglong(data , (unsigned long long*) value , big) ;
      else
          return  get_uint(data , (unsigned int*) value , big) ;
}

int    get_longlong(const unsigned  char *data  , long long  *value, int big)
{
          int  w , v ;
          get_int(data , &w , big) ;
          get_int(data + 4 , &v , big) ;
           if (big != 0)
          {
               *value = w ;
               *value = ((*value) << 32)  + v ;
          }
          else
          {
               *value = v ;
               *value = ((*value) << 32)  + w ;
          }
          return 8 ;
}

int    get_ulonglong(const unsigned  char *data  , unsigned long long  *value, int big)
{
          unsigned int  w , v ;
          get_uint(data , &w , big) ;
          get_uint(data + 4 , &v , big) ;
           if (big != 0)
          {
               *value = w ;
               *value = ((*value) << 32)  + v ;
          }
          else
          {
               *value = v ;
               *value = ((*value) << 32)  + w ;
          }
          return 8 ;
}

int     get_data(const unsigned  char *data , unsigned char *value ,  int sz)
{
    memcpy(value , data ,  sz) ;
    return sz ;
}

int    get_string(const unsigned char *data , int sz ,  char *sztemp , int mlen)
{
     int i  , pos ;
     if (mlen < 3*sz)
         return -1 ;
     for (i = 0 , pos = 0 ; i < sz ; ++i)
           pos += sprintf(sztemp + pos  , "%02x " , (unsigned char)data[i]) ;
     sztemp[pos] = '\0' ;
     return pos ;
}
