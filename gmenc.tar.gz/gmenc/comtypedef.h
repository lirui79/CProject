/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/



#ifndef  COM_TYPE_DEFINED_H
#define COM_TYPE_DEFINED_H 1

//   port
#define       ENC_NET_PORT                 39008

// Log level
#define        ENC_LOGLEVEL_DEBUG             0
#define        ENC_LOGLEVEL_INFO              1
#define        ENC_LOGLEVEL_WARN              2
#define        ENC_LOGLEVEL_ERROR             3
#define        ENC_LOGLEVEL_FATAL             4

//return code
#define SDR_OK                                   	0x0	             //   operate ock
#define SDR_UNKNOWERR	                0x01000001	 //   unkown error
#define SDR_NOTSUPPORT                  	0x01000002	 //   unsupported interface  call
#define SDR_COMMFAIL	                    0x01000003   //   communicate   device  failure
#define SDR_HARDFAIL                     	0x01000004   //   the device not response
#define SDR_OPENDEVICE                   	0x01000005   //   open the device  failure
#define SDR_OPENSESSION	                0x01000006   //    create session failure
#define SDR_PARDENY	                        0x01000007   //    no private key usage
#define SDR_KEYNOTEXIST	                0x01000008   //    not exist for the key call
#define SDR_ALGNOTSUPPORT             0x01000009   //    unsupported algorithm call
#define SDR_ALGMODNOTSUPPORT	    0x01000010  //    unsupported  algorithm mode call
#define SDR_PKOPERR                      	0x01000011   //    Public key operation failed
#define SDR_SKOPERR	                        0x01000012   //    Private key operation failed
#define SDR_SIGNERR	                        0x01000013   //    signature operation failed
#define SDR_VERIFYERR	                    0x01000014   //    verify signature failed
#define SDR_SYMOPERR	                    0x01000015   //    symmetric algorithm operation failure
#define SDR_STEPERR	                        0x01000016   //    multiple step operation error
#define SDR_FILESIZEERR	                    0x01000017   //    file length out of limit
#define SDR_FILENOEXIST	                0x01000018   //    the specified file does not exist
#define SDR_FILEOFSERR	                    0x01000019   //    file start position error
#define SDR_KEYTYPEERR	                    0x01000020   //    key type error
#define SDR_KEYERR	                            0x01000021   //    key error
//	0x00000020ÖÁ0x00FFFFFF                                      //    reserve
#define SDR_CONNECT_CONFIG            0x000001030   // read config fiel error
#define SDR_CONNECT_SERVER             0x000001031   // connect server error
#define SDR_SENDDATATO_SERVER        0x000001032   // send data server error
#define SDR_RECVDATAFROM_SERVER    0x000001033   // recv data from server error
#define SDR_DATAFORMAT_ERROR         0x000001040   // recv data format wrong from server

#define    ENC_MAX_LEN                      4096

#define    ENC_MAX_CON                      64

#define    ENC_MAX_ADDRESS                  32

#define    ENC_MAX_LISTEN                   5

#define    ENC_MAX_TIMEOUT                  5000

#define    ENC_MAX_EVENTS                   128


#endif // NCURSES_CPLUS_INTERNAL_H
