/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/

#include  "comtypedef.h"
#include  "comfundef.h"
#include "gmenmode.h"
#include  "sjy130_define.h"
//#include  "sjy130_error.h"
#include  "api.h"
#include  "sjy130_sf.h"
#include <malloc.h>



int    gm_device_fun(unsigned char *idata , int isz , unsigned char **odata ,  int *osz , int *msz)
{
      void *hDHandle , *hSHandle ;
      struct DeviceInfo_st    st_Devinfo ;
      int     len , pos , code  ;
      unsigned short  uiLength , uiKeyIndex ;
      unsigned char   *szTemp = *odata , tag = idata[0] ;
      pos = 0 ;
      pos += get_uchar(idata + pos , &tag) ;
      pos += get_int(idata + pos , &len , 1) ;
      switch (tag)
      {
          case  0x00 : //   SDF_OpenDevice
          len = 4 ;
          if ((code = SDF_OpenDevice(&hDHandle)) == SDR_OK)
             len = 8 ;

           pos = 0 ;
           pos += put_uchar(szTemp + pos , tag) ;
           pos += put_int(szTemp + pos ,  len , 1) ;
           if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
           else
           {
               pos += put_int(szTemp + pos , SDR_OPENDEVICE , 1) ;
               break ;
           }
          pos += put_int(szTemp + pos , (int)hDHandle , 1) ;
          break ;
          case  0x01 : //   SDF_CloseDevice
          pos += get_int(idata + pos , (int*)&hDHandle , 1) ;
          len = 4 ;
          code = SDF_CloseDevice(hDHandle);

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          case  0x02 : //   SDF_OpenSession
          pos += get_int(idata + pos , (int*)&hDHandle , 1) ;
          len = 4 ;
          if ((code = SDF_OpenSession(hDHandle , &hSHandle)) == SDR_OK)
             len = 8 ;

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_OPENSESSION , 1) ;
               break ;
           }
          pos += put_int(szTemp + pos , (int)hSHandle , 1) ;
          break ;
          case  0x03 : //   SDF_CloseSession
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          len = 4 ;
          code = SDF_CloseSession(hSHandle);

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          case  0x04 : //   SDF_GetDeviceInfo
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          len = 4 ;
          if ((code = SDF_GetDeviceInfo(hSHandle , &st_Devinfo)) == SDR_OK)
             len = 0x68 ;

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_COMMFAIL , 1) ;
               break ;
           }
          pos += put_data(szTemp + pos , st_Devinfo.IssuerName , sizeof(st_Devinfo.IssuerName)) ;
          pos += put_data(szTemp + pos , st_Devinfo.DeviceName , sizeof(st_Devinfo.DeviceName)) ;
          pos += put_data(szTemp + pos , st_Devinfo.DeviceSerial , sizeof(st_Devinfo.DeviceSerial)) ;

          pos += put_uint(szTemp + pos ,  st_Devinfo.DeviceVersion , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.StandardVersion , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.AsymAlgAbility[0] , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.AsymAlgAbility[1] , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.SymAlgAbility , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.HashAlgAbility , 1) ;
          pos += put_uint(szTemp + pos , st_Devinfo.BufferSize , 1) ;
          break ;
          case  0x05 : //   SDF_GenerateRandom
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;

          if ((*msz)  < (uiLength + 16))
          {
              if ((*odata) != NULL)
                    free(*odata) ;
              *msz = (uiLength + 16) ;
              *odata = szTemp = malloc(*msz) ;
           }

          len = 4 ;
          if ((code = SDF_GenerateRandom(hSHandle , (unsigned int) uiLength , szTemp + 9)) == SDR_OK)
             len = 0x04 + uiLength ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          if (code != SDR_OK)
             break ;
          pos += uiLength ;
          break ;
          case  0x06 : //   SDF_GetPrivateKeyAccessRight
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;

          len = 4 ;
          code = SDF_GetPrivateKeyAccessRight(hSHandle , (unsigned int)uiKeyIndex , idata + pos ,  (unsigned int) uiLength);
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          case  0x07 : //   SDF_ReleasePrivateKeyAccessRight
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          len = 4 ;
          code = SDF_ReleasePrivateKeyAccessRight(hSHandle , (unsigned int)uiKeyIndex);
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          default :
          code = SDR_NOTSUPPORT ;
          pos = 0 ;
          len = 4 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
       }
      *osz = pos ;
      return code ;
}

int    gm_mkey_fun(unsigned char *idata , int isz , unsigned char **odata ,  int *osz , int *msz)
{
      void  *hSHandle ,  *hKHandle ;
      struct ECCrefPublicKey_st    pubKey ;
      struct ECCCipher_st             cipher ;
      int     len , pos , code  ;
      unsigned short  uiKeyBits , uiKeyIndex , uiAlgID ;
      unsigned char   *szTemp = *odata , tag = idata[0] ;
      pos = 0 ;
      pos += get_uchar(idata + pos , &tag) ;
      pos += get_int(idata + pos , &len , 1) ;
     switch (tag)
      {
          case  0x20 : //   SDF_ExportSignPublicKey_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          len = 4 ;
          if ((code = SDF_ExportSignPublicKey_ECC(hSHandle , (unsigned int)uiKeyIndex , &pubKey))  == SDR_OK)
             len = 0x88 ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_PKOPERR , 1) ;
               break ;
           }

          pos += put_uint(szTemp + pos ,  pubKey.bits , 1) ;
          pos += put_data(szTemp + pos , pubKey.x , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , pubKey.y , ECCref_MAX_LEN) ;
          break ;
          case  0x21 : //   SDF_ExportEncPublicKey_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          len = 4 ;
          if ((code = SDF_ExportEncPublicKey_ECC(hSHandle , (unsigned int)uiKeyIndex , &pubKey))  == SDR_OK)
             len = 0x88 ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_PKOPERR , 1) ;
               break ;
           }

          pos += put_uint(szTemp + pos ,  pubKey.bits , 1) ;
          pos += put_data(szTemp + pos , pubKey.x , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , pubKey.y , ECCref_MAX_LEN) ;
          break ;
          case  0x22 : //   SDF_GenerateKeyWithIPK_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyBits , 1) ;

          if ((*msz)  < (16 + uiKeyBits / 8))
          {
              if ((*odata) != NULL)
                    free(*odata) ;
              *msz = (16 + uiKeyBits / 8) ;
              *odata = szTemp = malloc(*msz) ;
           }

          len = 4 ;
          if ((code = SDF_GenerateKeyWithIPK_ECC(hSHandle , (unsigned int)uiKeyIndex , (unsigned int) uiKeyBits , &cipher ,  &hKHandle))  == SDR_OK)
             len = (0x08 + uiKeyBits / 8) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_KEYERR , 1) ;
               break ;
           }

          pos += put_int(szTemp + pos ,   (int)hKHandle , 1) ;
          pos += put_data(szTemp + pos , cipher.x , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.y , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.M , sizeof(cipher.M)) ;
          pos += put_uint(szTemp + pos ,  cipher.L , 1) ;
          pos += put_data(szTemp + pos , cipher.C , cipher.L) ;
          break ;
          case  0x23 : //   SDF_ImportKeyWithISK_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;

          pos += get_data(idata + pos , cipher.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos , cipher.y , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos , cipher.M , sizeof(cipher.M)) ;
          pos += get_uint(idata + pos ,  &(cipher.L) , 1) ;
          pos += get_data(idata + pos , cipher.C , cipher.L) ;

          len = 4 ;
          if ((code = SDF_ImportKeyWithISK_ECC(hSHandle , (unsigned int)uiKeyIndex , &cipher ,  &hKHandle))  == SDR_OK)
             len = 0x08 ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_KEYERR , 1) ;
               break ;
           }

          pos += put_int(szTemp + pos , (int)hKHandle , 1) ;
          break ;
          case  0x24 : //   SDF_ExchangeDigitEnvelopeBaseOnECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;

          pos += get_uint(idata + pos , &(pubKey.bits) , 1) ;
          pos += get_data(idata + pos ,  pubKey.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos , pubKey.y , ECCref_MAX_LEN) ;

          pos += get_data(idata + pos , cipher.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos , cipher.y , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos , cipher.M , sizeof(cipher.M)) ;
          pos += get_uint(idata + pos ,  &(cipher.L) , 1) ;
          pos += get_data(idata + pos , cipher.C , cipher.L) ;

          len = 4 ;
 //         if ((code = SDF_ExchangeDigitEnvelopeBaseOnECC(hSHandle , (unsigned int)uiKeyIndex , (unsigned int) uiAlgID , &pubKey , &cipher ,  &cipher))  == SDR_OK)
         if ((code = SDF_ExchangeDigitEnvelopeBaseOnECC(hSHandle , (unsigned int)uiKeyIndex , &pubKey , &cipher ,  &cipher))  == SDR_OK)
          {
              len = 0xA8 + cipher.L  ;
              if ((*msz)  < (cipher.L + 256))
              {
                  if ((*odata) != NULL)
                        free(*odata) ;
                  *msz = (cipher.L + 256) ;
                  *odata = szTemp = malloc(*msz) ;
               }
           }

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_KEYERR , 1) ;
               break ;
           }

          pos += put_data(szTemp + pos , cipher.x , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.y , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.M , sizeof(cipher.M)) ;
          pos += put_uint(szTemp + pos ,  cipher.L , 1) ;
          pos += put_data(szTemp + pos , cipher.C , cipher.L) ;
          break ;
          case  0x25 : //   SDF_DestoryKey
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_int(idata + pos , (int*)&hKHandle , 1) ;
          len = 4 ;
          code = SDF_DestoryKey(hSHandle , hKHandle) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_KEYERR , 1) ;
               break ;
           }

          break ;
          default :
          code = SDR_NOTSUPPORT ;
          pos = 0 ;
          len = 4 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
       }
      *osz = pos ;
      return code ;
}

int    gm_asy_key__fun(unsigned char *idata , int isz , unsigned char **odata ,  int *osz , int *msz)
{
      void *hSHandle ;
      struct ECCrefPublicKey_st    pubKey ;
      struct ECCSignature_st        signature ;
      struct ECCCipher_st             cipher ;
      int     len , pos , code  ;
      unsigned short  uiLength , uiKeyIndex , uiAlgID ;
      unsigned char   *szTemp = *odata , tag = idata[0] , *pucData ;
      pos = 0 ;
      pos += get_uchar(idata + pos , &tag) ;
      pos += get_int(idata + pos , &len , 1) ;
     switch (tag)
      {
          case  0x40 : //   SDF_ExternalVerify_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;

          pos += get_uint(idata + pos , &(pubKey.bits) , 1) ;
          pos += get_data(idata + pos ,  pubKey.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos ,  pubKey.y , ECCref_MAX_LEN) ;

          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucData = idata + pos ;
          pos += uiLength ;

          pos += get_data(idata + pos ,  signature.r , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos ,  signature.s , ECCref_MAX_LEN) ;
          len = 4 ;
          code = SDF_ExternalVerify_ECC(hSHandle  , (unsigned int)uiAlgID , &pubKey , pucData , (unsigned int) uiLength , &signature) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_VERIFYERR , 1) ;
               break ;
           }

          break ;
          case  0x41 : //   SDF_InternalSign_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucData = idata + pos ;
          pos += uiLength ;
          len = 4 ;
          if ((code = SDF_InternalSign_ECC(hSHandle  , (unsigned int)uiKeyIndex ,  pucData , (unsigned int) uiLength , &signature)) == SDR_OK)
             len = 0x84 ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_SIGNERR , 1) ;
               break ;
           }
          pos += put_data(szTemp + pos ,  signature.r , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos ,  signature.s , ECCref_MAX_LEN) ;
          break ;
          case  0x42 : //   SDF_InternalVerify_ECC
         pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiKeyIndex , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucData = idata + pos ;
          pos += uiLength ;

          pos += get_data(idata + pos ,  signature.r , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos ,  signature.s , ECCref_MAX_LEN) ;
          len = 4 ;
          code = SDF_InternalVerify_ECC(hSHandle  , (unsigned int)uiKeyIndex , pucData , (unsigned int) uiLength , &signature) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_VERIFYERR , 1) ;
               break ;
           }

          break ;
          case  0x43 : //   SDF_ExternalEncrypt_ECC
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;

          pos += get_uint(idata + pos , &(pubKey.bits) , 1) ;
          pos += get_data(idata + pos ,  pubKey.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos ,  pubKey.y , ECCref_MAX_LEN) ;

          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucData = idata + pos ;
          pos += uiLength ;
          len = 4 ;
          if ((code = SDF_ExternalEncrypt_ECC(hSHandle  , (unsigned int)uiAlgID , &pubKey ,  pucData , (unsigned int) uiLength , &cipher)) == SDR_OK)
          {
              len = 0xA8 + cipher.L  ;
              if ((*msz)  < (cipher.L + 256))
              {
                  if ((*odata) != NULL)
                        free(*odata) ;
                  *msz = (cipher.L + 256) ;
                  *odata = szTemp = malloc(*msz) ;
               }
           }

          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          if (code == SDR_OK)
               pos += put_int(szTemp + pos , code , 1) ;
          else
           {
               pos += put_int(szTemp + pos , SDR_SKOPERR , 1) ;
               break ;
           }

          pos += put_data(szTemp + pos , cipher.x , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.y , ECCref_MAX_LEN) ;
          pos += put_data(szTemp + pos , cipher.M , sizeof(cipher.M)) ;
          pos += put_uint(szTemp + pos ,  cipher.L , 1) ;
          pos += put_data(szTemp + pos , cipher.C , cipher.L) ;
          break ;
          default :
          code = SDR_NOTSUPPORT ;
          pos = 0 ;
          len = 4 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
       }
      *osz = pos ;
      return code ;
}

int    gm_sy_key_fun(unsigned char *idata , int isz , unsigned char **odata ,  int *osz , int *msz)
{
      void *hKHandle , *hSHandle ;
      int     len , pos , code  ;
      unsigned short  uiLength , uiAlgID ;
      unsigned int  uiEnLength;
      unsigned char   *szTemp = *odata , tag = idata[0] , *pucData , *pucIV ;
      pos = 0 ;
      pos += get_uchar(idata + pos , &tag) ;
      pos += get_int(idata + pos , &len , 1) ;
      pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
      pos += get_int(idata + pos , (int*)&hKHandle , 1) ;
      pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;
      pucIV = idata + pos ;
      pos += 16 ;
      pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
      pucData = idata + pos ;
      pos += uiLength ;

      if ((*msz)  < (uiLength + 256))
      {
          if ((*odata) != NULL)
                free(*odata) ;
          *msz =  (uiLength + 256) ;
          *odata = szTemp = malloc(*msz) ;
       }

      len = 4 ;
     switch (tag)
      {
          case  0x60 : //   SDF_Encrypt
          if ((code = SDF_Encrypt(hSHandle  , hKHandle , (unsigned int)uiAlgID , pucIV ,  pucData , (unsigned int) uiLength , szTemp + 11 , &uiEnLength)) == SDR_OK)
             len = 0x06 + uiEnLength  ;
          break ;
          case  0x61 : //   SDF_Decrypt
           if ((code = SDF_Decrypt(hSHandle , hKHandle , (unsigned int)uiAlgID , pucIV ,  pucData , (unsigned int) uiLength , szTemp + 11 , &uiEnLength)) == SDR_OK)
             len = 0x06 + uiEnLength  ;
          break ;
       }

      pos = 0 ;
      pos += put_uchar(szTemp + pos , tag) ;
      pos += put_int(szTemp + pos ,  len , 1) ;
      if (code == SDR_OK)
      {
           pos += put_int(szTemp + pos , code , 1) ;
           pos += put_ushort(szTemp + pos ,  (unsigned short) uiEnLength , 1) ;
           pos += uiEnLength ;
      }
      else
       {
           pos += put_int(szTemp + pos , SDR_SYMOPERR , 1) ;
       }
      *osz = pos ;
      return code ;
}

int    gm_hash_fun(unsigned char *idata , int isz , unsigned char **odata ,  int *osz , int *msz)
{
      void   *hSHandle ;
      struct ECCrefPublicKey_st    pubKey ;
      int     len , pos , code  ;
      unsigned short  uiLength , uiAlgID ;
      unsigned int uiHLength ;
      unsigned char   *szTemp = *odata , tag = idata[0] , *pucID ;
      pos = 0 ;
      pos += get_uchar(idata + pos , &tag) ;
      pos += get_int(idata + pos , &len , 1) ;
     switch (tag)
      {
          case  0x80 : //   SDF_HashInit
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;

          pos += get_uint(idata + pos , &(pubKey.bits) , 1) ;
          pos += get_data(idata + pos ,  pubKey.x , ECCref_MAX_LEN) ;
          pos += get_data(idata + pos ,  pubKey.y , ECCref_MAX_LEN) ;

          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucID = idata + pos ;
          pos += uiLength ;
          len = 4 ;
          code = SDF_HashInit(hSHandle  , (unsigned int)uiAlgID , &pubKey  , pucID  , (unsigned int) uiLength) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          case  0x81 : //   SDF_HashUpdate
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;          //pos += get_ushort(idata + pos , (unsigned short*)&uiAlgID , 1) ;
          pos += get_ushort(idata + pos , (unsigned short*)&uiLength , 1) ;
          pucID = idata + pos ;
          pos += uiLength ;
          len = 4 ;
          code = SDF_HashUpdate(hSHandle  ,  pucID  , (unsigned int) uiLength) ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
          case  0x82 : //   SDF_HashFinal
          pos += get_int(idata + pos , (int*)&hSHandle , 1) ;
          len = 4 ;
          if ((code = SDF_HashFinal(hSHandle  , szTemp +  11 ,  &uiHLength) ) == SDR_OK)
              len = 6 + uiHLength ;
          pos = 0 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
           if (code != SDR_OK)
               break ;
          pos += put_ushort(szTemp + pos , (unsigned short) uiHLength , 1) ;
          pos += uiHLength ;
          break ;
          default :
          code = SDR_NOTSUPPORT ;
          pos = 0 ;
          len =  4 ;
          pos += put_uchar(szTemp + pos , tag) ;
          pos += put_int(szTemp + pos ,  len , 1) ;
          pos += put_int(szTemp + pos , code , 1) ;
          break ;
       }
      *osz = pos ;
      return code ;
}

int     gm_encrypt_fun(unsigned char *idata , int isz , unsigned char **odata , int *osz , int *msz)
{
      unsigned char  tag = idata[0] ;
      switch (tag)
      {
          case  0x00 : //   SDF_OpenDevice
          case  0x01 : //   SDF_CloseDevice
          case  0x02 : //   SDF_OpenSession
          case  0x03 : //   SDF_CloseSession
          case  0x04 : //   SDF_GetDeviceInfo
          case  0x05 : //   SDF_GenerateRandom
          case  0x06 : //   SDF_GetPrivateKeyAccessRight
          case  0x07 : //   SDF_ReleasePrivateKeyAccessRight
                    return gm_device_fun(idata , isz , odata , osz , msz) ;
          case  0x20 : //   SDF_ExportSignPublicKey_ECC
          case  0x21 : //   SDF_ExportEncPublicKey_ECC
          case  0x22 : //   SDF_GenerateKeyWithIPK_ECC
          case  0x23 : //   SDF_ImportKeyWithISK_ECC
          case  0x24 : //   SDF_ExchangeDigitEnvelopeBaseOnECC
          case  0x25 : //   SDF_DestoryKey
                    return gm_mkey_fun(idata , isz , odata , osz , msz) ;
          case  0x40 : //   SDF_ExternalVerify_ECC
          case  0x41 : //   SDF_InternalSign_ECC
          case  0x42 : //   SDF_InternalVerify_ECC
          case  0x43 : //   SDF_ExternalEncrypt_ECC
                    return gm_asy_key__fun(idata , isz , odata , osz , msz) ;
          case  0x60 : //   SDF_Encrypt
          case  0x61 : //   SDF_Decrypt
                    return gm_sy_key_fun(idata , isz , odata , osz , msz) ;
          case  0x80 : //   SDF_HashInit
          case  0x81 : //   SDF_HashUpdate
          case  0x82 : //   SDF_HashFinal
          default :
                   return gm_hash_fun(idata , isz , odata , osz , msz) ;
      }
      return SDR_UNKNOWERR ;
}
