// gmenclient.cpp : ���� DLL Ӧ�ó���ĵ���������
//


#include "gmenclient.h"
#include "comtypedef.h"
#include "netsocket.h"
#include "comfundef.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#ifdef  _WINDOWS

#include <time.h>
#include <winsock2.h>

static int sck_start = 0 ;
int socket_init_start()
{
    WSADATA wsaData;
	unsigned short sockVersion = MAKEWORD(2 , 2);
	int code ;
	if (sck_start == 1)
		return SDR_OK ;
	if( (code = WSAStartup(sockVersion, &wsaData)) != 0)
		return code ;
	sck_start = 1 ;
	return SDR_OK ;
}

#else
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#endif



typedef  struct gm_cconnect
{
   char saddress[ENC_MAX_ADDRESS] ;
   unsigned port ;
   int  socketid ;
} gm_cconnect ;

static struct gm_cconnect gcon = {"0.0.0.0" , 39008 , -1};

int getconfig(struct gm_cconnect *gmcon)
{
	char config[ENC_MAX_LEN] = "config" ;
	char sztmp[ENC_MAX_CON] ;

	FILE *file  ;
#ifdef  _WINDOWS
    GetModuleFileName(NULL , config , ENC_MAX_LEN) ;
	sprintf(strrchr(config , '\\') + 1  , "config") ;
#else
	readlink("/proc/self/exe" , config , ENC_MAX_LEN) ;
	sprintf(strrchr(config , '/') + 1  , "config") ;
#endif
	file = fopen(config , "r") ;

	if (gmcon->socketid >= 0)
		socket_close(gmcon->socketid) ;
	gmcon->socketid = -1 ;
	if (file == NULL)
		return -1 ;
    if (fgets(sztmp , ENC_MAX_CON , file) != NULL)
		strncpy(gmcon->saddress , sztmp , ENC_MAX_ADDRESS) ;
	else
	{
		fclose(file) ;
		return -2 ;
	}

    if (fgets(sztmp , ENC_MAX_CON , file) != NULL)
		gmcon->port =atoi(sztmp);
	else
	{
		fclose(file) ;
		return -3 ;
	}

    fclose(file) ;
	return 0 ;
}

int  gm_connect(struct gm_cconnect *gmcon)
{
#ifdef  _WINDOWS
	socket_init_start() ;
#endif

	if (getconfig(gmcon) < 0)
		return SDR_CONNECT_CONFIG ;
	gmcon->socketid = netsck_connect(gmcon->saddress , gmcon->port , AF_INET , SOCK_STREAM , 0 , 0) ;
	if (gmcon->socketid >= 0)
		return SDR_OK ;
	return SDR_CONNECT_SERVER ;
}

int gm_senddata(struct gm_cconnect *gmcon , const unsigned char *data , int sz)
{
	if (gmcon->socketid < 0)
		return -1 ;
	if (netsck_select(gmcon->socketid , 2000 , 1) < 0)
		return -2 ;
	if( netsck_send(gmcon->socketid , data , sz) == sz)
		return 0 ;
	return -3 ;
}

int gm_recvdata(struct gm_cconnect *gmcon , unsigned char *data , int *sz)
{
	int rsz = 0 , rhead = 0 , rsize = 0  ;
	if (gmcon->socketid < 0)
		return -1 ;

    while(1)
	{
		if (netsck_select(gmcon->socketid , 2000 , 0) < 0)
			return -2 ;

		if (netsck_canrsize(gmcon->socketid , &rsz) < 0)
			return -3 ;

		if (rhead < 1)
		{
			if (rsz < 5)
				continue ;

			if ( netsck_recv(gmcon->socketid , data , rsz) != rsz)
				return -4 ;

			get_int(data + 1 , sz , 1) ;
			*sz += 5 ;
			if (rsz >= *sz)
				return 0 ;
			rsize += rsz ;
			rhead = 1 ;
			continue ;
		}

		if( netsck_recv(gmcon->socketid , data + rsize , rsz) != rsz)
			return -5 ;

		rsize += rsz ;
		if (rsize >= *sz)
			return 0 ;
	}

	return 0 ;
}

int gm_recv(struct gm_cconnect *gmcon , unsigned char **data , int *sz)
{
	int rsz = 0 , rhead = 0 , rsize = 0  ;
	unsigned char rdata[ENC_MAX_LEN] , *rbuf ;
	*data = NULL ;

	if (gmcon->socketid < 0)
		return -1 ;

    while(1)
	{
		if (netsck_select(gmcon->socketid , 2000 , 0) < 0)
		{
			if ((*data) != NULL)
				free(*data) ;
			*data = NULL ;
			return -2 ;
		}

		if (netsck_canrsize(gmcon->socketid , &rsz) < 0)
		{
			if ((*data) != NULL)
				free(*data) ;
			*data = NULL ;
			return -3 ;
		}

		if (rhead < 1 )
		{
			if (rsz < 5)
				continue ;

			if (rsz >= ENC_MAX_LEN)
				rsz = ENC_MAX_LEN ;
			if ( netsck_recv(gmcon->socketid , rdata , rsz) != rsz)
				return -4 ;

			get_int(rdata + 1 , sz , 1) ;
			*sz += 5 ;
			*data = rbuf = malloc(*sz) ;
			memcpy(rbuf , rdata , rsz) ;
			if (rsz >= (*sz))
				return 0 ;
			rsize = rsz ;
			rhead = 1 ;
			continue ;
		}

		if( netsck_recv(gmcon->socketid , rbuf + rsize , rsz) != rsz)
		{
			if ((*data) != NULL)
				free(*data) ;
			*data = NULL ;
			return -5 ;
		}
		rsize += rsz ;
		if (rsize >= (*sz))
			return 0 ;
	}
	return 0 ;
}

#ifndef   SDF_OPENDEVICE

int GMENCLIENT_STDCALL SDF_OpenDevice(void **phDeviceHandle)
{
	unsigned char idata[8] , odata[16] , tag = 0x00;
	int  isz = 0 , osz = 0 , code , len = 0 ,  hHandle ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz ,  len , 1) ;

	code = gm_connect(&gcon) ;
	if ( code != SDR_OK)
		return code ;
    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	   if (len < 8)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_int(odata + isz , &hHandle , 1) ;
	   *phDeviceHandle = (void*) hHandle ;
	}
	return code ;
}

#else

int GMENCLIENT_STDCALL SDF_OpenDevice(void **phDeviceHandle)
{
	unsigned char idata[8] , *odata = NULL , tag = 0x00;
	int  isz = 0 , osz = 0 , code , len = 0 ,  hHandle ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz ,  len , 1) ;

	code = gm_connect(&gcon) ;
	if ( code != SDR_OK)
		return code ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recv(&gcon , &odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;

    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	   if (len < 8)
	   {
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
	   }
	   isz += get_int(odata + isz , &hHandle , 1) ;
	   *phDeviceHandle = (void*) hHandle ;
	}

	free(odata) ;
	return code ;
}

#endif

int GMENCLIENT_STDCALL SDF_CloseDevice(void *hDeviceHandle)
{
	unsigned char idata[16] , odata[16] , tag = 0x01;
	int  isz = 0 , osz = 0 , code , len = 4  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hDeviceHandle , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
		if (gcon.socketid >= 0)
			socket_close(gcon.socketid) ;
		gcon.socketid = -1 ;

#ifdef  _WINDOWS
		if (sck_start == 1)
			WSACleanup() ;
		sck_start = 0 ;
#endif
	}
	return code ;
}


int GMENCLIENT_STDCALL SDF_OpenSession(void *hDeviceHandle , void **phSessionHandle)
{
	unsigned char idata[16] , odata[16] , tag = 0x02;
	int  isz = 0 , osz = 0 , code , len = 4 ,  hHandle ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hDeviceHandle , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	   if (len < 8)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_int(odata + isz , &hHandle , 1) ;
	   *phSessionHandle =(void*) hHandle ;
	}
	return code ;
}

int GMENCLIENT_STDCALL SDF_CloseSession(void *hSessionHandle)
{
	unsigned char idata[16] , odata[16] , tag = 0x03;
	int  isz = 0 , osz = 0 , code , len = 4  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}

int GMENCLIENT_STDCALL  SDF_GetDeviceInfo(void *hSessionHandle , DEVICEINFO *pstDeviceInfo)
{
	unsigned char idata[16] , odata[128] , tag = 0x04;
	int  isz = 0 , osz = 0 , code , len = 4  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	   if (len < 0x68)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_data(odata + isz , pstDeviceInfo->IssuerName , sizeof(pstDeviceInfo->IssuerName)) ;
	   isz += get_data(odata + isz , pstDeviceInfo->DeviceName , sizeof(pstDeviceInfo->DeviceName)) ;
	   isz += get_data(odata + isz , pstDeviceInfo->DeviceSerial , sizeof(pstDeviceInfo->DeviceSerial)) ;

	   isz += get_uint(odata + isz , &(pstDeviceInfo->DeviceVersion) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->StandardVersion) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->AsymAlgAbility[0]) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->AsymAlgAbility[1]) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->SymAlgAbility) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->HashAlgAbility) , 1) ;
	   isz += get_uint(odata + isz , &(pstDeviceInfo->BufferSize) , 1) ;
	}
	return code ;
}


int GMENCLIENT_STDCALL SDF_GenerateRandom(void *hSessionHandle , unsigned int uiLength , unsigned char *pucRandom)
{
	unsigned char idata[16] ,  tag = 0x05 , *odata;
	int  isz = 0 , osz = 0 , code ;
	unsigned int len = 6  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_uint(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_short(idata + isz , (short)uiLength , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;

	odata = malloc(16 + uiLength) ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
	{
		free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_uint(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
		if (len < (uiLength + 4))
		{
			free(odata) ;
			return SDR_DATAFORMAT_ERROR ;
		}
		isz += get_data(odata + isz , pucRandom , uiLength) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_GetPrivateKeyAccessRight(void *hSessionHandle , unsigned int uiKeyIndex , unsigned char *pucPassword , unsigned int uiPwdLength)
{
	unsigned char *idata , odata[16] , tag = 0x06;
	int  isz = 0 , osz = 0 , code , len = 8 + uiPwdLength  ;
	idata = malloc( 16 + uiPwdLength) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyIndex , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiPwdLength , 1) ;
	isz += put_data(idata + isz , pucPassword , uiPwdLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}


int GMENCLIENT_STDCALL SDF_ReleasePrivateKeyAccessRight(void *hSessionHandle , unsigned int uiKeyIndex)
{
	unsigned char idata[16] ,  tag = 0x07 , odata[16] ;
	int  isz = 0 , osz = 0 , code , len = 6  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyIndex , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}



int GMENCLIENT_STDCALL SDF_ExportSignPublicKey_ECC(void *hSessionHandle , unsigned int uiKeyIndex , ECCrefPublicKey  *pucPublicKey)
{
	unsigned char idata[16] ,  tag = 0x20 , odata[256] ;
	int  isz = 0 , osz = 0 , code , len = 6  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyIndex , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;

	if (code == SDR_OK)
	{
	   if (len < 0x88)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_uint(odata + isz , &(pucPublicKey->bits) , 1) ;
	   isz += get_data(odata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	   isz += get_data(odata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;
	}
	return code ;
}


int GMENCLIENT_STDCALL SDF_ExportEncPublicKey_ECC(void *hSessionHandle , unsigned int uiKeyIndex , ECCrefPublicKey  *pucPublicKey)
{
	unsigned char idata[16] ,  tag = 0x21 , odata[256] ;
	int  isz = 0 , osz = 0 , code , len = 6  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyIndex , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;

	if (code == SDR_OK)
	{
	   if (len < 0x88)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_uint(odata + isz , &(pucPublicKey->bits) , 1) ;
	   isz += get_data(odata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	   isz += get_data(odata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;
	}
	return code ;
}

int GMENCLIENT_STDCALL  SDF_GenerateKeyWithIPK_ECC(void *hSessionHandle , unsigned int uiIPKIndex , unsigned int uiKeyBits , ECCCipher *pucKey , void **phKeyHandle)
{
	unsigned char idata[16] ,  tag = 0x22 , *odata ;
	int  isz = 0 , osz = 0 , code ,  hHandle ;
	unsigned int len = 8 ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_uint(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiIPKIndex , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyBits , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;

	odata = malloc(16 + (uiKeyBits / 8)) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
	{
		free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_uint(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
		if (len < ((uiKeyBits / 8) + 8))
		{
			free(odata) ;
			return SDR_DATAFORMAT_ERROR ;
		}
	    isz += get_int(odata + isz , &hHandle , 1) ;
	    *phKeyHandle = (void*) hHandle ;
	    isz += get_data(odata + isz , pucKey->x , ECCref_MAX_LEN) ;
	    isz += get_data(odata + isz , pucKey->y , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucKey->M , sizeof(pucKey->M)) ;
		isz += get_uint(odata + isz , &(pucKey->L) , 1) ;
		isz += get_data(odata + isz , pucKey->C , pucKey->L) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_ImportKeyWithISK_ECC(void *hSessionHandle , unsigned int uiISKIndex , ECCCipher *pucKey , void **phKeyHandle)
{
	unsigned char *idata , odata[16] , tag = 0x23;
	int  isz = 0 , osz = 0 , code , len = 0xAA + pucKey->L ,  hHandle ;
	idata = malloc( 16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiISKIndex , 1) ;
	isz += put_data(idata + isz , pucKey->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucKey->y , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucKey->M , sizeof(pucKey->M)) ;
	isz += put_uint(idata + isz , pucKey->L , 1) ;
	isz += put_data(idata + isz , pucKey->C , pucKey->L) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	   if (len < 8)
		   return SDR_DATAFORMAT_ERROR ;
	   isz += get_int(odata + isz , &hHandle , 1) ;
	   *phKeyHandle =(void*)  hHandle ;
	}
	return code ;
}

int GMENCLIENT_STDCALL SDF_ExchangeDigitEnvelopeBaseOnECC(void *hSessionHandle , unsigned int uiKeyIndex , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , ECCCipher *pucEncDataIn , ECCCipher *pucEncDataOut)
{
	unsigned char *idata , *odata , tag = 0x24;
	int  isz = 0 , osz = 0 , code ;
	unsigned int len = 0x0130 + pucEncDataIn->L  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_uint(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiKeyIndex , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_uint(idata + isz , pucPublicKey->bits , 1) ;
	isz += put_data(idata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;

	isz += put_data(idata + isz , pucEncDataIn->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucEncDataIn->y , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucEncDataIn->M , sizeof(pucEncDataIn->M)) ;
	isz += put_uint(idata + isz , pucEncDataIn->L , 1) ;
	isz += put_data(idata + isz , pucEncDataIn->C , pucEncDataIn->L) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recv(&gcon , &odata , &osz) < 0)
	{
		if (odata != NULL)
			free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_uint(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0xA8)
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucEncDataOut->x , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucEncDataOut->y , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucEncDataOut->M , sizeof(pucEncDataOut->M)) ;
		isz += get_uint(odata + isz , &(pucEncDataOut->L) , 1) ;

		if (len < (0xA8 + pucEncDataOut->L))
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucEncDataOut->C , pucEncDataOut->L) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_DestoryKey(void *hSessionHandle , void *hKeyHandle)
{
	unsigned char idata[16] , odata[16] , tag = 0x25 ;
	int  isz = 0 , osz = 0 , code , len = 8  ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_int(idata + isz , (int)hKeyHandle , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;
    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_ExternalVerify_ECC(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature)
{
	unsigned char *idata , odata[16] , tag = 0x40;
	int  isz = 0 , osz = 0 , code , len = 0x010C + uiDataLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_uint(idata + isz , pucPublicKey->bits , 1) ;
	isz += put_data(idata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

	isz += put_data(idata + isz , pucSignature->r , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucSignature->s , ECCref_MAX_LEN) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_InternalSign_ECC(void *hSessionHandle , unsigned int uiISKIndex , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature)
{
	unsigned char *idata , odata[256] , tag = 0x41;
	int  isz = 0 , osz = 0 , code , len = 0x08 + uiDataLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiISKIndex , 1) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0x84)
		   return SDR_DATAFORMAT_ERROR ;

		isz += get_data(odata + isz , pucSignature->r , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucSignature->s , ECCref_MAX_LEN) ;
	}
	return code ;
}

int GMENCLIENT_STDCALL SDF_InternalVerify_ECC(void *hSessionHandle , unsigned int uiISKIndex , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature)
{
	unsigned char *idata , odata[256] , tag = 0x42;
	int  isz = 0 , osz = 0 , code , len = 0x88 + uiDataLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiISKIndex , 1) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

	isz += put_data(idata + isz , pucSignature->r , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucSignature->s , ECCref_MAX_LEN) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_ExternalEncrypt_ECC(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucData , unsigned int uiDataLength , ECCCipher *pucEncData)
{
	unsigned char *idata , *odata , tag = 0x43;
	int  isz = 0 , osz = 0 , code ;
	unsigned int len = 0x08C + uiDataLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_uint(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_uint(idata + isz , pucPublicKey->bits , 1) ;
	isz += put_data(idata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recv(&gcon , &odata , &osz) < 0)
	{
		if (odata != NULL)
			free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_uint(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0xA8)
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucEncData->x , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucEncData->y , ECCref_MAX_LEN) ;
		isz += get_data(odata + isz , pucEncData->M , sizeof(pucEncData->M)) ;
		isz += get_uint(odata + isz , &(pucEncData->L) , 1) ;
		if (len < (0xA8 + pucEncData->L))
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucEncData->C , pucEncData->L) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_Encrypt(void *hSessionHandle , void *hKeyHandle , unsigned int uiAlgID , unsigned char *pucIV , unsigned char *pucData , unsigned int uiDataLength , unsigned char *pucEncData , unsigned int *puiEncDataLength)
{
	unsigned char *idata , *odata , tag = 0x60;
	int  isz = 0 , osz = 0 , code , len = 0x1C + uiDataLength  ;
	unsigned short ensz ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_int(idata + isz , (int)hKeyHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_data(idata + isz , pucIV , 16) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recv(&gcon , &odata , &osz) < 0)
	{
		if (odata != NULL)
			free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0x06)
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}
		isz += get_ushort(odata + isz , &ensz , 1) ;
		*puiEncDataLength = ensz ;
		if (len < (0x06 + ensz))
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucEncData , ensz) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL  SDF_Decrypt(void *hSessionHandle , void *hKeyHandle , unsigned int uiAlgID , unsigned char *pucIV , unsigned char *pucEncData , unsigned int uiEncDataLength , unsigned char *pucData , unsigned int *puiDataLength)
{
	unsigned char *idata , *odata , tag = 0x61;
	int  isz = 0 , osz = 0 , code , len = 0x1C + uiEncDataLength  ;
	unsigned short ensz ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_int(idata + isz , (int)hKeyHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_data(idata + isz , pucIV , 16) ;

	isz += put_ushort(idata + isz , (unsigned short)uiEncDataLength , 1) ;
	isz += put_data(idata + isz , pucEncData , uiEncDataLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recv(&gcon , &odata , &osz) < 0)
	{
		if (odata != NULL)
			free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}
    isz = 0 ;
	isz += get_char(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0x06)
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}
		isz += get_ushort(odata + isz , &ensz , 1) ;
		*puiDataLength = ensz ;
		if (len < (0x06 + ensz))
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucData , ensz) ;
	}
	free(odata) ;
	return code ;
}

int GMENCLIENT_STDCALL SDF_HashInit(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucID , unsigned int uiIDLength)
{
	unsigned char *idata , odata[16] , tag = 0x80;
	int  isz = 0 , osz = 0 , code , len = 0x08C + uiIDLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;
	isz += put_ushort(idata + isz , (unsigned short)uiAlgID , 1) ;

	isz += put_uint(idata + isz , pucPublicKey->bits , 1) ;
	isz += put_data(idata + isz , pucPublicKey->x , ECCref_MAX_LEN) ;
	isz += put_data(idata + isz , pucPublicKey->y , ECCref_MAX_LEN) ;

	isz += put_ushort(idata + isz , (unsigned short)uiIDLength , 1) ;
	isz += put_data(idata + isz , pucID , uiIDLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;

	return code ;
}

int GMENCLIENT_STDCALL SDF_HashUpdate(void *hSessionHandle , unsigned char *pucData , unsigned int uiDataLength)
{
	unsigned char *idata , odata[16] , tag = 0x81;
	int  isz = 0 , osz = 0 , code , len = 0x06 + uiDataLength  ;
	idata = malloc(16 + len) ;
	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;	//isz += put_short(idata + isz , (short)uiAlgID , 1) ;

	isz += put_ushort(idata + isz , (unsigned short)uiDataLength , 1) ;
	isz += put_data(idata + isz , pucData , uiDataLength) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
	{
		free(idata) ;
		return SDR_SENDDATATO_SERVER ;
	}
	free(idata) ;

    if (gm_recvdata(&gcon , odata , &osz) < 0)
		return SDR_RECVDATAFROM_SERVER ;
    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;

	return code ;
}

int GMENCLIENT_STDCALL SDF_HashFinal(void *hSessionHandle , unsigned char *pucHash , unsigned int *puiHashLength)
{
	unsigned char idata[16] , *odata , tag = 0x82;
	int  isz = 0 , osz = 0 , code , len = 0x04  ;
	unsigned short rsz ;

	isz += put_uchar(idata + isz , tag) ;
	isz += put_int(idata + isz , len , 1) ;
	isz += put_int(idata + isz , (int)hSessionHandle , 1) ;	//isz += put_short(idata + isz , (short)uiAlgID , 1) ;

    if (gm_senddata(&gcon , idata , isz) < 0)
		return SDR_SENDDATATO_SERVER ;

    if (gm_recv(&gcon , &odata , &osz) < 0)
	{
		if (odata != NULL)
			free(odata) ;
		return SDR_RECVDATAFROM_SERVER ;
	}

    isz = 0 ;
	isz += get_uchar(odata + isz , &tag) ;
	isz += get_int(odata + isz , &len , 1) ;
	isz += get_int(odata + isz , &code , 1) ;
	if (code == SDR_OK)
	{
	    if (len < 0x06)
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}
		isz += get_ushort(odata + isz , &rsz , 1) ;
		*puiHashLength = rsz ;
		if (len < (0x06 + rsz))
		{
		   free(odata) ;
		   return SDR_DATAFORMAT_ERROR ;
		}

		isz += get_data(odata + isz , pucHash , rsz) ;
	}
	free(odata) ;
	return code ;
}
