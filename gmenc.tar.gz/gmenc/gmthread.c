
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/

#include "gmthread.h"
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <time.h>

void   thread_run( void* (*th_fn)(void *args) , void *args)
{
	pthread_t  pthreadId ;
	pthread_create(&pthreadId , NULL ,  th_fn ,  args);
	pthread_detach(pthreadId);
}

int      thread_mcond_t_init( struct  m_cond_t * mcond_t)
{
	if (0 != pthread_mutex_init(&(mcond_t->mutex) , NULL))
	    return -1 ;

	if (0 !=pthread_cond_init(&(mcond_t->cond_t) , NULL))
	    return -2 ;
	mcond_t->signal = 0 ;
	return 0 ;
}

void    thread_mcond_t_destroy( struct  m_cond_t * mcond_t)
{
    pthread_mutex_destroy(&(mcond_t->mutex));
    pthread_cond_destroy(&(mcond_t->cond_t));
}

int      thread_wait(struct  m_cond_t * mcond_t , unsigned  int ts)
{
	int nWait = 1 ;
	struct timespec now;
	pthread_mutex_lock(&(mcond_t->mutex));

	if (mcond_t->signal > 0)
		nWait = 0 ;
	else
	{
		while(clock_gettime(CLOCK_REALTIME, &now) != 0)
				; // -lrt 库
		ts += (unsigned long)(now.tv_nsec / 1000 /1000);
		now.tv_sec += ( ts / 1000) ;
		ts = (ts % 1000) ;
		now.tv_nsec = ((long long)ts) * 1000 * 1000;
		nWait = 1 ;
		if (0 == pthread_cond_timedwait(&(mcond_t->cond_t), &(mcond_t->mutex) , &now)) // true - 非超时   false - 超时
		   nWait = 0;
	}
	mcond_t->signal = 0 ;
	pthread_mutex_unlock(&(mcond_t->mutex));
	return nWait ;
}

void       thread_signal(struct  m_cond_t * mcond_t)
{
	pthread_mutex_lock(&(mcond_t->mutex));
	pthread_cond_signal(&(mcond_t->cond_t));
    mcond_t->signal = 1 ;
	pthread_mutex_unlock(&(mcond_t->mutex));
}

