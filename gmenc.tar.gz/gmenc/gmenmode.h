
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/



#ifndef  GM_ENC_MODE_H
#define GM_ENC_MODE_H 1



int     gm_encrypt_fun(unsigned char *idata , int isz , unsigned char **odata , int *osz , int *msz) ;




#endif // GM_ENC_MODE_H

