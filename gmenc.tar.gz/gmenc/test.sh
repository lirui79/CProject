#!/bin/sh
echo " --------------- Kill sntp Program --------------"
#killall sntp

cd ./bin

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../lib


echo "Set LD_LIBRARY_PATH = "$LD_LIBRARY_PATH
echo " --------------- Run Test Program ---------------"
./gmtest $*
echo " --------------- Test Program End ---------------"

