

int S_ICOnline(HANDLE hDeviceHandle);
int S_ICReady(HANDLE hSessionHandle);
int S_ICLinkDevice(HANDLE hDeviceHandle);

int S_ICResetDevice(HANDLE hDeviceHandle);

int S_ICInitDevice(HANDLE hDeviceHandle);

int S_ICReadID(HANDLE hDeviceHandle,unsigned char *pID,unsigned short *pIDLen);

int S_ICGetRandom(HANDLE hDeviceHandle,unsigned char *pRandom,unsigned short nRandomLen);

int S_ICSelectFile(HANDLE hDeviceHandle,unsigned short nFileID,S_ICFILEINFO *pFileInfo);

int S_ICReadFile(HANDLE hDeviceHandle,int nOffset,int nDataLen,unsigned char *pData,int *nReturned);

int S_ICWriteFile(HANDLE hDeviceHandle,int nOffset,int nDataLen,unsigned char *pData,int *nWritten);

int S_ICCreateFile(HANDLE hDeviceHandle,unsigned short nFileID,unsigned short nFileLength);

int S_ICVerifyPin(HANDLE hDeviceHandle,unsigned char *pPin,unsigned short nPinLen);

int S_ICModifyPin(HANDLE hDeviceHandle,unsigned char *pOldPin,unsigned short nOldPinLen,unsigned char *pNewPin,unsigned short nNewPinLen);

int S_ICGetFreeSpace(HANDLE hDeviceHandle,unsigned short *FreeSpace);

int S_ICCreateRSAFile(HANDLE hDeviceHandle,unsigned short nPKFileID,unsigned short nVKFileID);

int S_ICGenerateKeyPair(HANDLE hDeviceHandle,int nFlag,unsigned short nPKFileID,unsigned short nVKFileID,RSArefPublicKey *pPublicKey,RSArefPrivateKey *pPrivateKey);

int S_ICReadPK(HANDLE hDeviceHandle,unsigned short nPKFileID,RSArefPublicKey *pPublicKey);

int S_ICWriteKeyPair(HANDLE hDeviceHandle,unsigned short nPKFileID,unsigned short nVKFileID,RSArefPublicKey *pPublicKey,RSArefPrivateKey *pPrivateKey);

//RSA����
int S_ICRsaEncry(HANDLE hDeviceHandle,unsigned short nPKFileID,unsigned char *pInData,int nInDataLen, unsigned char *pOutData,int *pOutDataLen);

//RSA����
int S_ICRsaDecry(HANDLE hDeviceHandle,unsigned short nVKFileID,unsigned char *pInData,int nInDataLen, unsigned char *pOutData,int *pOutDataLen);
