#define  RESETCARD      99 
#define  CLEANMODULE    98
#define  READCOUNT      97
#define  WRITECOUNT      96
#define  READHANDLE      95
#define  WRITEHANDLE      94
#define  READLINKHANDLE      93
#define  WRITELINKHANDLE      92

#define  CARDOPERATE	91
#define  CARDMAXNUM      5
int en3_kernel_cleanup_module(void);
