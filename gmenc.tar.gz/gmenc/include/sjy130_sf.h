
int S_WriteRsaEnKEYPair(HANDLE hSessionHandle,unsigned int keyid,unsigned char* key,unsigned int keylen,unsigned char* pRsaEnKeyPairData,unsigned int  pInDataLen);

int S_WriteRsaSnKEYPair( HANDLE hSessionHandle,unsigned int keyid,unsigned char* key,unsigned int keylen,unsigned char* pRsaSnKeyPairData,unsigned int  pInDataLen);

int S_WriteECCEnKeyPair(HANDLE hSessionHandle,unsigned int  keyid,unsigned char* key,unsigned int keylen,unsigned char* pECCEnKeyPairData,unsigned int pInDataLen);

int S_WriteECCSnKeyPair(HANDLE hSessionHandle,unsigned int  keyid,unsigned char* key,unsigned int keylen,unsigned char* pECCSnKeyPairData,unsigned int  pInDataLen);

int S_ReadRsaEnKEYPair(HANDLE hSessionHandle,unsigned int keyid,unsigned char* key,unsigned int keylen,unsigned char* pRsaEnKeyPairData, unsigned int * pOutDataLen );

int S_ReadRsaSnKEYPair(HANDLE hSessionHandle,unsigned int keyid,unsigned char* key,unsigned int keylen,unsigned char* pRsaSnKeyPairData,unsigned int * pOutDataLen);

int S_ReadECCEnKEYPair(HANDLE hSessionHandle,unsigned int  keyid,unsigned char* key,unsigned int keylen,unsigned char* pECCEnKeyPairData,unsigned int * pOutDataLen);

int S_ReadECCSnKEYPair(HANDLE hSessionHandle,unsigned int  keyid,unsigned char* key,unsigned int keylen,unsigned char* pECCSnKeyPairData,unsigned int * pOutDataLen);

int S_BackKEK(HANDLE hSessionHandle,unsigned char *Password,unsigned int PasswordLength,unsigned int index,unsigned char *enKEK);

int S_RenewKEK(HANDLE hSessionHandle,unsigned char *Password,unsigned int PasswordLength,unsigned int index,unsigned char *enKEK);
