#ifdef __cplusplus
extern "C"{
#endif
int S_GetErrorInfo(HANDLE hSessionHandle);
int S_GenerateExportKPK(HANDLE hSessionHandle,unsigned char *Password,unsigned int PasswordLen,unsigned char *EnKPK,unsigned int *EnKPKlen);
int S_ImportKPK(HANDLE hSessionHandle,unsigned char *Password,unsigned int PasswordLen,unsigned char *EnKPK,unsigned int EnKPKlen);
int S_BackUpEncEccKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncECCKeyPair,unsigned int *EncECCKeyPairLength);
int S_BackUpSignEccKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncECCKeyPair,unsigned int *EncECCKeyPairLength);
int S_RestoreEncEccKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncECCKeyPair,unsigned int EncECCKeyPairLength);
int S_RestoreSignEccKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncECCKeyPair,unsigned int EncECCKeyPairLength);
int S_BackUpEncRSAKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncRSAKeyPair,unsigned int *EncRSAKeyPairLength);
int S_BackUpSignRSAKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncRSAKeyPair,unsigned int *EncRSAKeyPairLength);
int S_RestoreEncRSAKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncRSAKeyPair,unsigned int EncRSAKeyPairLength);
int S_RestoreSignRSAKeyPair(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncRSAKeyPair,unsigned int EncRSAKeyPairLength);
int S_BackUpKEK(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncKEK,unsigned int *EncKEKLength);
int S_RestoreKEK(HANDLE hSessionHandle,unsigned int keyIndex,unsigned char *EncKEK,unsigned int EncKEKLength);
int S_ChangePrivateKeyAccessRight(HANDLE   hSessionHandle,unsigned int  uiKeyIndex,unsigned char *oldpucPassword,unsigned int uioldPwdlength,unsigned char *newpucPassword,unsigned int  uiPwdLength);
int S_TestModule(HANDLE phDeviceHandle,	unsigned short *status);
int S_ResetModule(HANDLE phDeviceHandle);
//��֤���뿨��Pin����
int S_VerifyPin(HANDLE phDeviceHandle,unsigned char *pPin,unsigned int nPinLen,unsigned int PinType);
//�޸����뿨��Pin����
int S_ModifyPin(HANDLE phDeviceHandle,unsigned char *pOldPin,unsigned int nOldPinLen,	unsigned char *pNewPin,	unsigned int nNewPinLen	);
int S_Init_FileSystem(HANDLE hSessionHandle);
int S_GenerateEncKeyPair_RSA(HANDLE hSessionHandle,unsigned int uiKeyIndex,unsigned int keybits);
int S_GenerateSignKeyPair_RSA(HANDLE hSessionHandle,unsigned int uiKeyIndex,unsigned int keybits);

int S_GenerateEncKeyPair_ECC(HANDLE hSessionHandle,unsigned int uiKeyIndex);
int S_GenerateSignKeyPair_ECC(HANDLE hSessionHandle,unsigned int uiKeyIndex);
int S_GenerateKEK(HANDLE hSessionHandle,unsigned int uiKeyIndex,unsigned int byteslen);

int S_DecryptEx(HANDLE hSessionHandle,unsigned char *endata,int enlen,unsigned char *keybuf,int keylen,unsigned char *IV,int IVLen,int uiAlgID,unsigned char *data,int *len);

int S_EncryptEx(HANDLE hSessionHandle,unsigned char *data,int len,unsigned char *keybuf,int keylen,unsigned char *IV,int IVLen,int uiAlgID,unsigned char *endata,int *enlen);

int S_NVELOPEDKEY(HANDLE hSessionHandle,unsigned int uiKEKIndex,unsigned int ulAsymmAlgID,unsigned int ulSymmAlgID,unsigned char *CipherBlob,unsigned int CipherBloblength,unsigned char *PubKey,unsigned int PubKeylen,unsigned char *cbEncryptedPriKey,unsigned int cbEncryptedPriKeylen);

int S_Init_Device(HANDLE  phDeviceHandle,S_UCHAR *pin,unsigned int pinlen);
int  S_GetDeviceStatus(HANDLE phDeviceHandle,unsigned short *CardStatus,unsigned short *PermissionStatus);
int  S_ISTORS(HANDLE phDeviceHandle);
int  S_RSTOIS(HANDLE phDeviceHandle);
int  S_FSTOIS(HANDLE phDeviceHandle);
//===========================================================================
int  SDF_OpenDevice(HANDLE *phDeviceHandle);

int SDF_CloseDevice(HANDLE   phDeviceHandle);

int SDF_OpenSession(HANDLE phDeviceHandle,HANDLE *phSessionHandle);

int SDF_CloseSession(HANDLE  hSessionHandle);

int SDF_GetDeviceInfo (HANDLE  hSessionHandle,DEVICEINFO *pstDeviceInfo);

int SDF_GenerateRandom(HANDLE  hSessionHandle, unsigned int   uiLength,unsigned char *pucRandom);

int SDF_GetPrivateKeyAccessRight(HANDLE   hSessionHandle,unsigned int  uiKeyIndex,unsigned char *pucPassword,unsigned int  uiPwdLength);

int SDF_ReleasePrivateKeyAccessRight(HANDLE  hSessionHandle,unsigned int  uiKeyIndex);

int SDF_ExportSignPublicKey_RSA(HANDLE hSessionHandle,unsigned int  uiKeyIndex,RSArefPublicKey *pucPublicKey);

int SDF_ExportEncPublicKey_RSA(HANDLE hSessionHandle,unsigned int  uiKeyIndex,RSArefPublicKey *pucPublicKey);
	
int SDF_Factory_Setting(HANDLE phDeviceHandle,unsigned short *status);//������ʼ��
	
int SDF_GenerateKeyPair_RSA(HANDLE hSessionHandle,unsigned int  uiKeyBits,RSArefPublicKey *pucPublicKey,RSArefPrivateKey *pucPrivateKey);

int SDF_GenerateKeyWithIPK_RSA(HANDLE hSessionHandle,unsigned int uiIPKIndex,unsigned int uiKeyBits,unsigned char *pucKey,unsigned int *puiKeyLength,void **phKeyHandle);

int SDF_GenerateKeyWithEPK_RSA(HANDLE hSessionHandle,unsigned int uiKeyBits,RSArefPublicKey *pucPublicKey,unsigned char *pucKey,unsigned int *puiKeyLength,HANDLE *phKeyHandle);

int SDF_ImportKeyWithISK_RSA (HANDLE hSessionHandle,unsigned int uiISKIndex,	unsigned char *pucKey,unsigned int *puiKeyLength,HANDLE *phKeyHandle);

int SDF_ExchangeDigitEnvelopeBaseOnRSA(HANDLE hSessionHandle,unsigned int uiKeyIndex,RSArefPublicKey *pucPublicKey,unsigned char *pucDEInput,unsigned int uiDELength,unsigned char *pucDEOutput,unsigned int *puiDELength);

int SDF_ExportSignPublicKey_ECC(HANDLE hSessionHandle,unsigned int  uiKeyIndex,	ECCrefPublicKey *pucPublicKey);

int SDF_ExportEncPublicKey_ECC(HANDLE hSessionHandle,unsigned int  uiKeyIndex,	ECCrefPublicKey *pucPublicKey);

int SDF_GenerateKeyPair_ECC(HANDLE hSessionHandle,unsigned int  uiAlgID,unsigned int  uiKeyBits,ECCrefPublicKey *pucPublicKey,ECCrefPrivateKey *pucPrivateKey);

int SDF_GenerateKeyWithIPK_ECC (HANDLE hSessionHandle,unsigned int uiIPKIndex,unsigned int uiKeyBits,	ECCCipher *pucKey,HANDLE  *phKeyHandle);

int SDF_GenerateKeyWithEPK_ECC (HANDLE hSessionHandle,unsigned int uiKeyBits,ECCrefPublicKey *pucPublicKey,ECCCipher *pucKey,HANDLE  *phKeyHandle);

int SDF_ImportKeyWithISK_ECC (HANDLE hSessionHandle,unsigned int uiISKIndex,ECCCipher *pucKey,HANDLE  *phKeyHandle);

int SDF_ExchangeDigitEnvelopeBaseOnECC(HANDLE hSessionHandle,unsigned int uiKeyIndex,ECCrefPublicKey *pucPublicKey,ECCCipher *pucEncDataIn,ECCCipher *pucEncDataOut);

int SDF_GenerateKeyWithKEK (HANDLE hSessionHandle,unsigned int uiKeyBits,unsigned int  uiAlgID,unsigned int uiKEKIndex,unsigned char *pucKey,unsigned int *puiKeyLength, HANDLE   *phKeyHandle);

int SDF_ImportKeyWithKEK(HANDLE hSessionHandle,unsigned int uiAlgID,unsigned int uiKEKIndex,unsigned char *pucKey,unsigned int *puiKeyLength,HANDLE *phKeyHandle);

int SDF_ImportKey (HANDLE  hSessionHandle,unsigned char *pucKey,unsigned int uiKeyLength,HANDLE   *phKeyHandle);

int SDF_DestoryKey (HANDLE  hSessionHandle, HANDLE  hKeyHandle);

int S_ExternalSign_ECC(HANDLE  hSessionHandle,unsigned int uiAlgID,ECCrefPrivateKey *pucPrivateKey,unsigned char *pucData,unsigned int  uiDataLength,ECCSignature *pucSignature);

int SDF_ExternalVerify_ECC(HANDLE  hSessionHandle,unsigned int uiAlgID,ECCrefPublicKey *pucPublicKey,unsigned char *pucDataInput,unsigned int  uiInputLength,ECCSignature *pucSignature);

int SDF_InternalSign_ECC(HANDLE  hSessionHandle,unsigned int  uiISKIndex,unsigned char *pucData,unsigned int  uiDataLength,ECCSignature *pucSignature);

int SDF_InternalVerify_ECC(HANDLE   hSessionHandle,unsigned int  uiISKIndex,unsigned char *pucData,unsigned int  uiDataLength,ECCSignature *pucSignature);

int SDF_ExternalEncrypt_ECC(HANDLE hSessionHandle,unsigned int uiAlgID,ECCrefPublicKey *pucPublicKey,unsigned char *pucData,unsigned int uiDataLength,ECCCipher *pucEncData);

int S_ExternalDecrypt_ECC(HANDLE  hSessionHandle,unsigned int uiAlgID,ECCrefPrivateKey *pucPrivateKey,ECCCipher *pucEncData,unsigned char *pucData,unsigned int  *puiDataLength);

int SDF_ExternalPublicKeyOperation_RSA(HANDLE  hSessionHandle,RSArefPublicKey *pucPublicKey,unsigned char *pucDataInput,unsigned int  uiInputLength,unsigned char *pucDataOutput,unsigned int  *puiOutputLength);

int S_ExternalPrivateKeyOperation_RSA(HANDLE  hSessionHandle,RSArefPrivateKey *pucPrivateKey,unsigned char *pucDataInput,unsigned int  uiInputLength,unsigned char *pucDataOutput,unsigned int  *puiOutputLength);

int SDF_InternalPublicKeyOperation_RSA(HANDLE  hSessionHandle,unsigned int  uiKeyIndex,	unsigned char *pucDataInput,unsigned int  uiInputLength,unsigned char *pucDataOutput,unsigned int  *puiOutputLength);

int SDF_InternalPrivateKeyOperation_RSA(HANDLE   hSessionHandle,unsigned int  uiKeyIndex,unsigned char *pucDataInput,unsigned int  uiInputLength,unsigned char *pucDataOutput,unsigned int  *puiOutputLength);


int SDF_Encrypt(HANDLE  hSessionHandle,HANDLE  hKeyHandle,unsigned int uiAlgID,	unsigned char *pucIV,unsigned char *pucData,unsigned int uiDataLength,unsigned char *pucEncData,unsigned int  *puiEncDataLength);

int SDF_Decrypt (HANDLE  hSessionHandle,HANDLE  hKeyHandle,unsigned int uiAlgID,unsigned char *pucIV,unsigned char *pucEncData,unsigned int  uiEncDataLength,	unsigned char *pucData,unsigned int *puiDataLength);

int SDF_CalculateMAC(HANDLE hSessionHandle,HANDLE hKeyHandle,unsigned int uiAlgID,unsigned char *pucIV,unsigned char *pucData,unsigned int uiDataLength,unsigned char *pucMAC,unsigned int *puiMACLength);

int SDF_HashInit(HANDLE hSessionHandle,unsigned int uiAlgID,ECCrefPublicKey *pucPublicKey,unsigned char *pucID,unsigned int uiIDLength);

int SDF_HashUpdate(HANDLE hSessionHandle,unsigned char *pucData,unsigned int uiDataLength);

int SDF_HashFinal(HANDLE hSessionHandle,unsigned char *pucHash,unsigned int *puiHashLength);

int SDF_CreateFile(HANDLE hSessionHandle,unsigned char *pucFileName,unsigned int uiNameLen,unsigned int uiFileSize);

int SDF_ReadFile(HANDLE hSessionHandle,unsigned char *pucFileName,unsigned int uiNameLen,unsigned int uiOffset,unsigned int *puiFileLength,unsigned char *pucBuffer);

int SDF_WriteFile(HANDLE hSessionHandle,unsigned char *pucFileName,unsigned int uiNameLen,unsigned int uiOffset,unsigned int uiFileLength,unsigned char *pucBuffer);

int SDF_DeleteFile(HANDLE hSessionHandle,unsigned char *pucFileName,unsigned int uiNameLen);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int S_SetAssisantPin(HANDLE pDeviceHandle,S_UCHAR *pin,unsigned int pinlen,unsigned int PinType);

void keyextokey(unsigned char *inputkey,unsigned char *outputkey);

void longtochar(unsigned char *inputdata,unsigned char *outputdata,unsigned int inputlength);

int S_RsaPadding(HANDLE hSessionHandle,unsigned int bits,unsigned char *input,int inputlen,unsigned char *padoutput,int *padoutlen,int flag);

int S_RsaEreasePadding(HANDLE hSessionHandle,unsigned int bits,unsigned char *PadData,int PadDataLen,unsigned char*outData,int *outDataLen,int flag);

int S_RsaEncrypt_Ex(HANDLE hSessionHandle,RSArefPublicKey *PublicKey,unsigned char *Indata,unsigned int InDataLen,unsigned char *Endata,unsigned int *EnDataLen)
;
int S_RsaDecrypt_Ex(HANDLE hSessionHandle,RSArefPrivateKey *PrivateKey,unsigned char *Indata,unsigned int InDataLen,unsigned char *outdata,unsigned int *OutdataLen);

int S_RsaSign_Ex(HANDLE hSessionHandle,RSArefPrivateKey *PrivateKey,unsigned char *Indate,unsigned int InDataLen,unsigned char *Signdata,unsigned int *SigndataLen);

int S_RsaVerify_Ex(HANDLE hSessionHandle,RSArefPublicKey *PublicKey,unsigned char *Signdata,unsigned int SigndataLen,unsigned char *outdata,unsigned int *outdataLen);

int S_SelectMod(HANDLE Device,unsigned int ModeAlog,unsigned char *password,unsigned int Passwordlen);

int S_WriteRsaSignKeyPairEx(HANDLE hSessionHandle,unsigned int keyID,RSArefPublicKey *publicKey,RSArefPrivateKey *privatekey);

int S_WriteRsaEnKeyPairEx(HANDLE hSessionHandle,unsigned int keyID,RSArefPublicKey *publicKey,RSArefPrivateKey *privatekey);


int S_WriteECCSignKeyPairEx(HANDLE hSessionHandle,unsigned int keyID,ECCrefPublicKey *publicKey,ECCrefPrivateKey *privatekey);

int S_WriteECCEnKeyPairEx(HANDLE hSessionHandle,unsigned int keyID,ECCrefPublicKey *publicKey,ECCrefPrivateKey *privatekey);

int S_WriteKEKEx(HANDLE hSessionHandle,unsigned int index,unsigned char *key,unsigned int keylong);

int HashSM3(HANDLE hSessionHandle,ECCrefPublicKey *pucPublicKey,unsigned char *pucID,unsigned int uiIDLength,unsigned char *pucData,unsigned int uiDataLength,unsigned char *pucHash,unsigned int *uipucHashlength);
//////////////////////////////////////////������ʼ������///////////////////////////////
int S_ICCardUserKeyRestore(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,int ICNum);
int S_ICCardDeviceKeyRestore(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,int ICNum);
int S_ICCardUserKeyBackUp(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,int ICNum);
int S_ICCardDeviceKeyBackUp(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,int ICNum);
////////////////////////////////////////���ù���Ա��////////////////////////////

int S_ICCardSet(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,unsigned short CardType);
int S_SetAssisantPin(HANDLE pDeviceHandle,S_UCHAR *pin,unsigned int pinlen,unsigned int PinType);
////////////////////////////////////////��Կ�ָ�����/////////////////////////////////////
int S_ICCardLoad(HANDLE DeviceHandle,unsigned char *Password,unsigned int PasswordLen,unsigned short *CardType);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////ϵͳ��ʼ������////////////////////////////////////////

/// �Ϻ��������� START-->
    
int S_LpGenerateMk(IN HANDLE hSessionHandle,
				   IN unsigned int MkId,
				   IN unsigned char *MkSeed1,
				   IN unsigned int MkSeed1len,
				   IN unsigned char *MkSeed2,
				   IN unsigned int MkSeed2len);
    
int S_MkEncryptOut(
				   IN HANDLE hSessionHandle,
				   IN unsigned int dMkId,
				   OUT unsigned char *penMk,
				   OUT unsigned char *psmk_part1,
				   OUT unsigned char *psmk_part2,
				   OUT unsigned char *psmk_part3);
    
int S_EnMkDecryptIn(
					IN HANDLE hSessionHandle,
                                        IN unsigned int SFlag,
					IN unsigned int dMkId,
					IN unsigned char *penMk,
					IN unsigned char *psmk_part1,
					IN unsigned char *psmk_part2,
					IN unsigned char *psmk_part3);
    
int S_GMEncryptOut(
				   IN  HANDLE        hSessionHandle,
				   IN  unsigned int  dMkId,
				   IN  unsigned int  dSeedLength,
				   IN  unsigned char *pSeed,
				   IN  unsigned int  uiAlgID,
				   IN  unsigned char *pTokenSerial,
				   IN  unsigned char *pfactureMes,
				   OUT unsigned char *pServerEncrypedSeed,
				   OUT unsigned int  *pServerEncryptedSeedLen,
				   OUT unsigned char *pFactureEncryptedSeed,
				   OUT unsigned int  *pFactureEncryptedSeedLen);
    
int S_GMDecryptOut(
				   IN HANDLE         hSessionHandle,
				   IN unsigned int   dMkId,
				   IN unsigned char* pTokenSerial,
				   IN unsigned char  *pServerEncrypedSeed,
				   IN unsigned int   dServerEncryptedSeedLen,
				   IN unsigned int   uiAlgID,
				   OUT unsigned char *TokenSeed,
				   OUT unsigned int  *TokenSeedlength);
    
int S_GMDecryptOutWithKp(
						 IN HANDLE         hSessionHandle,
						 IN unsigned int   PkId,
						 IN unsigned char  *pTokenSerial,
						 IN unsigned char  *pFactureEncryptedSeed,
						 IN unsigned int   dFactureEncryptedSeedLen,
						 IN unsigned int   uiAlgID,
						 OUT unsigned char *TokenSeed,
						 OUT unsigned int  *TokenSeedlength);
    
int S_ExportKp(
			   IN HANDLE         hSessionHandle,
			   IN unsigned int   PkId,
			   IN unsigned char  *pfactureMes,
			   OUT unsigned char *EncryptKp,
			   OUT unsigned int  *EncryptKpLen,
			   OUT unsigned char *secretPart1,
			   OUT unsigned int  *secretPart1Length,
			   OUT unsigned char *secretPart2,
			   OUT unsigned int  *secretPart2Length,
			   OUT unsigned char *secretPart3,
			   OUT unsigned int  *secretPart3Length);
    
int S_ImportKp(
			   IN HANDLE         hSessionHandle,
			   IN unsigned int   PkId,
			   IN unsigned char  *EncryptKp,
			   IN unsigned int   EncryptKpLen,
			   IN unsigned char  *secretPart1,
			   IN unsigned int   secretPart1Length,
			   IN unsigned char  *secretPart2,
			   IN unsigned int   secretPart2Length,
			   IN unsigned char  *secretPart3,
			   IN unsigned int   secretPart3Length);

/* ��IC��д���� */
int S_ICWriteBuff(IN HANDLE        hDeviceHandle,
				  IN unsigned char *pPin,
				  IN unsigned int  pinLen,
				  IN unsigned int  mkFileID,
				  IN unsigned int  offset,
				  IN unsigned char *pBuff,
				  IN unsigned int  buffLen);

/* ��IC�������� */
int S_ICReadBuff(IN HANDLE          hDeviceHandle,
				  IN unsigned char  *pPin,
				  IN unsigned int   pinLen,
				  IN unsigned int   mkFileID,
				  IN unsigned int   offset,
				  IN unsigned int   BuffToReadLen,
				  OUT unsigned char *pBuff,
        OUT unsigned int  *pBuffReadedLen);
        
/* �������Կ */
int S_ImportRootKey(IN HANDLE hSessionHandle,
					IN unsigned char *pRootKey,
					IN unsigned int dKeyLen);
					
/* ����ָ�����Կ */
int S_MKBootRecovery(IN HANDLE       hSessionHandle,
					             IN unsigned int dMkId);
    
    
/// �Ϻ��������� END--|

/*
int S_ECCDecryptIn (
	HANDLE hSessionHandle,
	unsigned int uiISKIndex,
	ECCCipher *pucKey,
	unsigned char *pucOutData,
	unsigned int *pucOutlength);

int S_ImportEncKeyPair_ECC(
	HANDLE hSessionHandle,
	unsigned int vkIndex,
	unsigned int uiAlgID,
	ECCCipher *pucSM2EncKey,
	unsigned char *pucSM2EnPrivateKey,
	unsigned int pucSM2EnPrivateKeylen,
	ECCrefPublicKey *publickey);

int S_RSADecryptIn (
	HANDLE hSessionHandle,
	unsigned int uiISKIndex,
	unsigned char *pucInData,
	unsigned int  pucInDatalength,
	unsigned char *pucOutData,
	unsigned int *pucOutlength);
*/
    
// ..

#ifdef _cplusplus
}
#endif
