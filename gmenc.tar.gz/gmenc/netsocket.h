/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/



#ifndef  NTE_SOCKET_H
#define NTE_SOCKET_H 1

void  socket_close(int sckid) ;

int   netsck_connect(const char *address ,  unsigned short port ,  int domain , int type , int protocol, int nonblock) ;

int   netsck_bind(const char *address , unsigned short port ,  int domain , int type , int protocol, int nonblock) ;

int   netsck_send(int socketid ,  const unsigned char *data , int size) ;

int   netsck_recv(int socketid ,  unsigned char *data , int size) ;

int   netsck_canrsize(int socketid ,   int *size) ;

int   netsck_select(int socketid , unsigned long ts , int type) ;


#endif // NTE_SOCKET_H
