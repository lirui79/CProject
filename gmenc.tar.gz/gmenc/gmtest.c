// gmtest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "gmenclient.h"

#ifdef  _WINDOWS
#include "stdafx.h"
#else
#include <signal.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int  nExit = 0 ;
void signal_handler(int sig)
{
	nExit =  1 ;	//write_log(0 , "press <Ctrl-C> Exit!\n") ;
	printf("press <Ctrl-C> Exit!\n") ;
}

void set_signal(int sig)
{
	struct sigaction sa;
	sa.sa_handler = SIG_IGN;//
	sa.sa_flags = 0;//	sigemptyset(&sa.sa_mask);
	sigaction(sig , &sa, 0) ;
}

int main(int argc, char* argv[])
{
	void *hHandle ;
	int code ;
   struct sigaction sa;    /* Establish the signal handler. */
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = ( void (*)(int) )signal_handler ;
    sigaction(SIGINT , &sa, NULL);

	code = SDF_OpenDevice(&hHandle) ;

	printf("%x\n" , code) ;

    //hHandle = (void *)0x000121abc ;
    if (code == 0)
    	code = SDF_CloseDevice(hHandle) ;

	printf("%x\n" , code) ;

	while(1)
	{
         if(nExit == 1)
             break ;
        //getchar() ;

	     sleep(1) ;
	}

	return 0;
}

