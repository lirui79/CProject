
/**********************************************************

history：
build time: 2016-11-22
author     : lirui

Copyright (c)   DTV   novel supertv . inc

************************************************************/

#include "gmlog.h"
#include "comtypedef.h"
#include "comfundef.h"
#include "gmthread.h"


#include <stdarg.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>


typedef   struct  logitem_node
{
      struct  logitem_node  *prev ;
      struct  logitem_node  *next ;
      char                           *msgs  ;
      int                                mlen ;
      int                                rlen ;
} logitem_node;

struct    logitem_node  loghead ;
int         g_iloglevel = ENC_LOGLEVEL_WARN ;
struct   m_cond_t      log_mcondt ;
int         iExit_log  = 0 ;
int         iW_log = 0 ;

char      g_pathlog[256] ;
char      g_szFileName[256] ;
int         g_Flog_size = 5  * 1024 * 1024 ;



int      write_lognodes()
{
        struct  logitem_node *lnode  , *next ;
        FILE *fp ;
        char szFileNew[256] , szNowTime[64];
        time_t nowtime ;
        struct  stat   statlog ;
        lnode = NULL ;
        pthread_mutex_lock(&(log_mcondt.mutex));
        if (loghead.next != &loghead)
        {
            lnode = loghead.next ;
            loghead.prev = &loghead ;
            loghead.next = &loghead ;
        }
        pthread_mutex_unlock(&(log_mcondt.mutex));

        if (lnode == NULL)
             return  -1;

        fp = fopen(g_szFileName , "a") ;
        while(lnode != &loghead)
        {        //  write log file        //    printf("%d  %d %s\n" , lnode->mlen , lnode->rlen , lnode->msgs) ;
            fprintf(fp , "%s\n" , lnode->msgs) ;
            next = lnode->next ;
            free(lnode->msgs) ;
            free(lnode) ;
            lnode = next ;
        }
        fclose(fp) ;

        if (stat(g_szFileName , &statlog) >= 0)
        {
             if (statlog.st_size >= g_Flog_size)
             {
                nowtime = time(0) ;
                strftime(szNowTime , 64 , "%F %X " , localtime(&nowtime) );
                sprintf(szFileNew , "%s/%s.log" , g_pathlog , szNowTime) ;
                rename(g_szFileName , szFileNew) ;
             }
        }

        return 0 ;
}


void  *writelogrun(void *args)
{
        int   ifind ;
        write_log(ENC_LOGLEVEL_INFO ,  128 , "The server write log thread start!") ;
        while(1)
        {
                if (iExit_log > 0)
                   break ;//

                if (write_lognodes()  >= 0)
                    continue ;
                thread_wait(&log_mcondt , ENC_MAX_TIMEOUT);
        }

        write_log(ENC_LOGLEVEL_INFO , 128 , "The server write log thread exit!") ;
        usleep(50000) ;
        write_lognodes() ;
        iExit_log = 2 ;
        return NULL;
}

int      logserver_init(int iloglevel)
{
       readlink("/proc/self/exe" , g_pathlog , 1024) ;
       sprintf(strrchr(g_pathlog , '/') + 1  , "log") ;
       if (access(g_pathlog , F_OK) == -1)
           mkdir(g_pathlog , S_IRWXU) ;

       sprintf(g_szFileName , "%s/gmen.log" , g_pathlog ) ;
       g_iloglevel = iloglevel ;
       thread_mcond_t_init(&log_mcondt) ;
       loghead.prev = &loghead ;
       loghead.next = &loghead ;
       loghead.msgs = NULL ;

        thread_run(writelogrun , &log_mcondt) ;
        return 0 ;
}


void   set_loglevel(int iloglevel)
{
      g_iloglevel = iloglevel ;
}

int      get_loglevel()
{
       return g_iloglevel ;
}


int      write_log(int  iloglevel  , int ilogsize , const char *format , ...)
{
        const char *szlevel[] = {"Debug" , "Info" , "Warn" , "Error" , "Fatal"} ;
        time_t nowtime = time(0);
        size_t  pos ;
        va_list args ;
        struct  logitem_node  *lnode ;
        if (iExit_log > 1)
            return 0 ;
        lnode = malloc(sizeof(struct logitem_node)) ;
        lnode->msgs = malloc(ilogsize) ;
        lnode->mlen = ilogsize ;
        pos  = strftime(lnode->msgs , 32 , "%F %X " , localtime(&nowtime) );
        if (iloglevel > 4)
              iloglevel = 4 ;
        pos +=sprintf(lnode->msgs + pos , "%s " , szlevel[iloglevel])       ;

        va_start(args , format) ; // The last argument to wvsprintf points to the arguments
        pos += vsnprintf(lnode->msgs + pos , ilogsize - pos , format , args); 	//   _vsntprintf (szBuf , sizeof (szBuf) , format , pArgList) ;
        va_end(args) ;
        lnode->rlen = pos ;
        if (iExit_log > 1)
        {
            free(lnode->msgs) ;
            free(lnode) ;
            return 0 ;
        }
        pthread_mutex_lock(&(log_mcondt.mutex));
        lnode->next = &loghead ;
        lnode->prev = loghead.prev ;
        lnode->prev->next = lnode ;
        loghead.prev = lnode ;
        pthread_mutex_unlock(&(log_mcondt.mutex));
//        thread_signal(&log_mcondt);
        return 0 ;
}

void   stop_log()
{
        iExit_log  = 1 ;
        thread_signal(&log_mcondt);
        while(iExit_log != 2)
           usleep(500000) ;

        thread_mcond_t_destroy(&log_mcondt) ;
}
