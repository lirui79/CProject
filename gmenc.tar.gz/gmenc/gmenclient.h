// ���� ifdef ���Ǵ���ʹ�� DLL �������򵥵�
// ��ı�׼�������� DLL �е������ļ��������������϶���� GMENCLIENT_EXPORTS
// ���ű���ġ���ʹ�ô� DLL ��
// �κ�������Ŀ�ϲ�Ӧ����˷��š�������Դ�ļ��а������ļ����κ�������Ŀ���Ὣ
// GMENCLIENT_API ������Ϊ�Ǵ� DLL ����ģ����� DLL ���ô˺궨���
// ������Ϊ�Ǳ������ġ�


#ifndef   GM_EN_CLIENT_H
#define   GM_EN_CLIENT_H

#ifdef  _WINDOWS

#ifdef GMENCLIENT_EXPORTS
#define GMENCLIENT_API __declspec(dllexport)
#else
#define GMENCLIENT_API __declspec(dllimport)
#endif

#define  GMENCLIENT_STDCALL  _stdcall

#else

#define GMENCLIENT_API 
#define  GMENCLIENT_STDCALL 

#endif

#ifdef __cplusplus  
extern "C" {  
#endif  

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_OpenDevice(void **phDeviceHandle) ;
 
  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_CloseDevice(void *hDeviceHandle) ;


  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_OpenSession(void *hDeviceHandle , void **phSessionHandle) ;

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_CloseSession(void *hSessionHandle) ;

typedef struct DeviceInfo_st{
	unsigned char IssuerName[40] ;
	unsigned char DeviceName[16] ;
	unsigned char DeviceSerial[16] ;
	unsigned int  DeviceVersion ;
	unsigned int  StandardVersion ;
	unsigned int  AsymAlgAbility[2] ;
	unsigned int  SymAlgAbility ;
	unsigned int  HashAlgAbility ;
	unsigned int  BufferSize ;
}DEVICEINFO ;

  GMENCLIENT_API int GMENCLIENT_STDCALL  SDF_GetDeviceInfo(void *hSessionHandle , DEVICEINFO *pstDeviceInfo) ;


  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_GenerateRandom(void *hSessionHandle , unsigned int uiLength , unsigned char *pucRandom) ;

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_GetPrivateKeyAccessRight(void *hSessionHandle , unsigned int uiKeyIndex , unsigned char *pucPassword , unsigned int uiPwdLength) ;


  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ReleasePrivateKeyAccessRight(void *hSessionHandle , unsigned int uiKeyIndex);

#define     ECCref_MAX_BITS     512
#define     ECCref_MAX_LEN      ((ECCref_MAX_BITS + 7) / 8)
typedef  struct   ECCrefPublicKey_st
{
	  unsigned  int  bits ;
	  unsigned  char x[ECCref_MAX_LEN] ;
	  unsigned  char y[ECCref_MAX_LEN] ;
}ECCrefPublicKey ;

typedef  struct   ECCCipher_st
{
	  unsigned  char x[ECCref_MAX_LEN] ;
	  unsigned  char y[ECCref_MAX_LEN] ;
	  unsigned  char M[32] ;
	  unsigned  int  L ;
	  unsigned  char C[1] ;
} ECCCipher ;

typedef  struct   ECCSignature_st
{
	  unsigned  char r[ECCref_MAX_LEN] ;
	  unsigned  char s[ECCref_MAX_LEN] ;
} ECCSignature;


  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ExportSignPublicKey_ECC(void *hSessionHandle , unsigned int uiKeyIndex , ECCrefPublicKey  *pucPublicKey);


  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ExportEncPublicKey_ECC(void *hSessionHandle , unsigned int uiKeyIndex , ECCrefPublicKey  *pucPublicKey);

  GMENCLIENT_API int GMENCLIENT_STDCALL  SDF_GenerateKeyWithIPK_ECC(void *hSessionHandle , unsigned int uiIPKIndex , unsigned int uiKeyBits , ECCCipher *pucKey , void **phKeyHandle);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ImportKeyWithISK_ECC(void *hSessionHandle , unsigned int uiISKIndex , ECCCipher *pucKey , void **phKeyHandle);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ExchangeDigitEnvelopeBaseOnECC(void *hSessionHandle , unsigned int uiKeyIndex , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , ECCCipher *pucEncDataIn , ECCCipher *pucEncDataOut);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_DestoryKey(void *hSessionHandle , void *hKeyHandle) ;

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ExternalVerify_ECC(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_InternalSign_ECC(void *hSessionHandle , unsigned int uiISKIndex , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_InternalVerify_ECC(void *hSessionHandle , unsigned int uiISKIndex , unsigned char *pucData , unsigned int uiDataLength , ECCSignature  *pucSignature);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_ExternalEncrypt_ECC(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucData , unsigned int uiDataLength , ECCCipher *pucEncData);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_Encrypt(void *hSessionHandle , void *hKeyHandle , unsigned int uiAlgID , unsigned char *pucIV , unsigned char *pucData , unsigned int uiDataLength , unsigned char *pucEncData , unsigned int *puiEncDataLength);

  GMENCLIENT_API int GMENCLIENT_STDCALL  SDF_Decrypt(void *hSessionHandle , void *hKeyHandle , unsigned int uiAlgID , unsigned char *pucIV , unsigned char *pucEncData , unsigned int uiEncDataLength , unsigned char *pucData , unsigned int *puiDataLength);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_HashInit(void *hSessionHandle , unsigned int uiAlgID , ECCrefPublicKey  *pucPublicKey , unsigned char *pucID , unsigned int uiIDLength);

  GMENCLIENT_API int GMENCLIENT_STDCALL SDF_HashUpdate(void *hSessionHandle , unsigned char *pucData , unsigned int uiDataLength);

GMENCLIENT_API int GMENCLIENT_STDCALL SDF_HashFinal(void *hSessionHandle , unsigned char *pucHash , unsigned int *puiHashLength);

#ifdef __cplusplus  
}  
#endif 

#endif // GM_EN_CLIENT_H